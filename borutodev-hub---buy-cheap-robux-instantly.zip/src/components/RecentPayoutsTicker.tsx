import { useState, useEffect } from 'react';
import { Zap, ShieldCheck, Clock, CheckCircle2 } from 'lucide-react';

interface LivePayout {
  id: string;
  username: string;
  avatarUrl: string;
  amount: number;
  timestamp: number;
  payoutTxId: string;
}

// Masks username to exactly 3 asterisks in the middle, e.g. @SOMJLN -> @S***LN, @Roblox -> @R***ox
function maskUsername(username: string): string {
  if (!username) return 'User';
  const clean = username.replace(/^@/, '');
  if (clean.length <= 2) {
    return `${clean.charAt(0)}***`;
  }
  if (clean.length <= 4) {
    return `${clean.charAt(0)}***${clean.slice(-1)}`;
  }
  // For longer names like SOMJLN -> S***LN or KacperPL -> K***PL
  const start = clean.slice(0, 1);
  const end = clean.slice(-2);
  return `${start}***${end}`;
}

export default function RecentPayoutsTicker() {
  const [livePayouts, setLivePayouts] = useState<LivePayout[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLivePayouts = async () => {
    try {
      const res = await fetch('/api/payouts/live');
      if (res.ok) {
        const data = await res.json();
        if (data.payouts && Array.isArray(data.payouts)) {
          setLivePayouts(data.payouts);
        }
      }
    } catch {
      // Quietly fall back without logging unhandled errors during server hot restarts
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLivePayouts();
    // Poll every 6 seconds for real user payouts
    const interval = setInterval(fetchLivePayouts, 6000);

    // Listen to local cashout event
    const handleVaultUpdated = () => {
      fetchLivePayouts();
    };
    window.addEventListener('vault_updated', handleVaultUpdated);

    return () => {
      clearInterval(interval);
      window.removeEventListener('vault_updated', handleVaultUpdated);
    };
  }, []);

  const getTimeAgo = (timestamp: number) => {
    const diffSec = Math.floor((Date.now() - timestamp) / 1000);
    if (diffSec < 45) return 'Just now';
    if (diffSec < 90) return '1m ago';
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
    return `${Math.floor(diffSec / 3600)}h ago`;
  };

  return (
    <div className="w-full bg-transparent border-b border-[#28282B]/60 text-xs py-2 px-4 overflow-hidden">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2.5">
        <div className="flex items-center gap-2 text-[#D4AF37] font-semibold shrink-0">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#D4AF37] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#D4AF37]"></span>
          </span>
          <span className="flex items-center gap-1.5 text-xs font-bold tracking-wide">
            <Zap className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
            Live Group Payouts:
          </span>
        </div>

        {/* Live verified payouts list - greyish pills on invisible background */}
        <div className="flex items-center gap-2 sm:gap-2.5 overflow-x-auto no-scrollbar w-full sm:w-auto py-0.5">
          {livePayouts.length > 0 ? (
            livePayouts.slice(0, 6).map((payout) => (
              <div
                key={payout.id}
                className="flex items-center gap-2 shrink-0 bg-[#161618] border border-[#28282B] hover:border-[#3E3E42] rounded-full px-3 py-1 transition shadow-xs text-xs"
              >
                {payout.avatarUrl ? (
                  <img
                    src={payout.avatarUrl}
                    alt={payout.username}
                    className="w-4 h-4 rounded-full bg-[#101012] object-cover border border-[#28282B] shrink-0"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                )}
                <span className="text-[#E4E4E7] font-medium">@{maskUsername(payout.username)}</span>
                <span className="text-[#D4AF37] font-mono font-bold">+{payout.amount.toLocaleString()} R$</span>
                <span className="text-[#71717A] text-[10px] flex items-center gap-0.5 font-medium">
                  <Clock className="w-2.5 h-2.5" />
                  {getTimeAgo(payout.timestamp)}
                </span>
              </div>
            ))
          ) : (
            <div className="text-[#71717A] text-xs flex items-center gap-1.5 bg-[#161618] border border-[#28282B] rounded-full px-3.5 py-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Automated Group Payout engine active & ready for claims</span>
            </div>
          )}
        </div>

        <div className="hidden lg:flex items-center gap-3 text-[#71717A] text-[11px] shrink-0">
          <span className="text-[#A1A1AA] font-medium">⚡ Avg. Speed: ~22s</span>
          <span className="text-[#28282B]">|</span>
          <span className="text-[#D4AF37] font-medium flex items-center gap-1">
            <span>BD STUDIO #36092915</span>
          </span>
        </div>
      </div>
    </div>
  );
}
