import { useState, useEffect } from 'react';
import { Zap, ShieldCheck, Users, ArrowRight, Lock, Clock, ExternalLink, Sparkles, SendHorizontal } from 'lucide-react';
import { formatNumber } from '../utils/helpers';

interface HeroSectionProps {
  onStartCashout: () => void;
  onOpenChecker: () => void;
  onOpenVault: () => void;
  memberCount?: number;
}

export default function HeroSection({ onStartCashout, onOpenChecker, onOpenVault, memberCount: initialMemberCount }: HeroSectionProps) {
  const [memberCount, setMemberCount] = useState<number>(initialMemberCount || 20);

  useEffect(() => {
    if (initialMemberCount !== undefined) {
      setMemberCount(initialMemberCount);
      return;
    }
    // Fetch live group info
    fetch('/api/vault/state')
      .then(res => res.json())
      .then(data => {
        if (typeof data.memberCount === 'number') {
          setMemberCount(data.memberCount);
        }
      })
      .catch(() => {});
  }, [initialMemberCount]);

  return (
    <section className="relative pt-8 pb-12 overflow-hidden">
      {/* Subtle ambient background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[360px] bg-[#D4AF37]/5 blur-[140px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto">
          
          {/* Status badge pill */}
          <div className="inline-flex items-center gap-2 bg-[#161618] border border-[#28282B] rounded-full px-4 py-1.5 mb-6 text-xs shadow-lg">
            <span className="flex items-center gap-1.5 text-[#D4AF37] font-bold">
              <span className="w-2 h-2 rounded-full bg-[#D4AF37] animate-pulse"></span>
              Official Vault: BD STUDIO (#36092915)
            </span>
            <span className="text-[#2E2E33]">|</span>
            <span className="text-[#A1A1AA] font-semibold flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 fill-[#D4AF37] text-[#D4AF37]" />
              Automated Group Payout Engine Active
            </span>
          </div>

          {/* Main Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black font-['Outfit',sans-serif] tracking-tight text-[#FFFFFF] leading-[1.1] mb-6">
            Automated Robux <br />
            <span className="text-[#D4AF37]">
              Group Payout System
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-[#A1A1AA] leading-relaxed mb-8 max-w-2xl mx-auto">
            Claim your Robux directly into your Roblox account in seconds. The system executes automated group payouts from <span className="text-[#D4AF37] font-bold">BD STUDIO (#36092915)</span> with instant hold verification and zero manual intervention.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-3.5 mb-4">
            <button
              id="hero-start-cashout-btn"
              onClick={onStartCashout}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-[#D4AF37] hover:bg-[#c49f2e] text-[#0A0A0C] font-bold text-sm sm:text-base shadow-lg shadow-[#D4AF37]/20 transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
            >
              <SendHorizontal className="w-4 h-4 text-[#0A0A0C]" />
              <span>Claim Robux</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              id="hero-checker-btn"
              onClick={onOpenChecker}
              className="w-full sm:w-auto px-5 py-3 rounded-xl bg-[#161618] hover:bg-[#1C1C1F] border border-[#28282B] hover:border-[#D4AF37]/50 text-[#FFFFFF] font-semibold text-sm sm:text-base transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer transform hover:-translate-y-0.5 whitespace-nowrap"
            >
              <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
              <span>14-Day Checker</span>
            </button>

            <a
              href="https://www.roblox.com/communities/36092915/BD-STUDIO#!/about"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-4 py-3 rounded-xl bg-[#161618] hover:bg-[#1C1C1F] border border-[#28282B] hover:border-[#71717A] text-[#A1A1AA] hover:text-white font-medium text-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <span>Join Group</span>
              <ExternalLink className="w-3.5 h-3.5 text-[#71717A]" />
            </a>
          </div>

          <div className="text-xs text-[#71717A] mb-10 flex items-center justify-center gap-2">
            <Sparkles className="w-4 h-4 text-[#D4AF37]" />
            <span>Instant API Disbursal • Verified Roblox Group Payouts • 100% Free Automation</span>
          </div>

          {/* 4 Trust Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-left">
            <div 
              onClick={onOpenVault}
              className="bg-[#161618] border border-[#28282B] hover:border-[#D4AF37]/40 rounded-[14px] p-4 flex items-center gap-3 transition cursor-pointer"
            >
              <div className="w-11 h-11 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37] shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <div className="text-base font-black text-white font-['Outfit',sans-serif]">Instant</div>
                <div className="text-[11px] text-[#71717A]">Automated Transfer</div>
              </div>
            </div>

            <div className="bg-[#161618] border border-[#28282B] rounded-[14px] p-4 flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-[#101012] border border-[#28282B] flex items-center justify-center text-[#D4AF37] shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <div className="text-base font-black text-white font-['Outfit',sans-serif]">No Passwords</div>
                <div className="text-[11px] text-[#71717A]">Public Roblox Username</div>
              </div>
            </div>

            <div 
              onClick={onOpenVault}
              className="bg-[#161618] border border-[#28282B] hover:border-[#D4AF37]/40 rounded-[14px] p-4 flex items-center gap-3 transition cursor-pointer"
            >
              <div className="w-11 h-11 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37] shrink-0">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <div className="text-base font-black text-white font-['Outfit',sans-serif]">{formatNumber(memberCount)}</div>
                <div className="text-[11px] text-[#71717A]">Official Members</div>
              </div>
            </div>

            <div className="bg-[#161618] border border-[#28282B] rounded-[14px] p-4 flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-[#101012] border border-[#28282B] flex items-center justify-center text-[#D4AF37] shrink-0">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <div className="text-base font-black text-white font-['Outfit',sans-serif]">100% Auto</div>
                <div className="text-[11px] text-[#71717A]">Direct Group Payout</div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
