import { useState, useEffect, useCallback } from 'react';
import { CashoutTicket } from '../types';
import { formatNumber, generateRobloxAvatarUrl } from '../utils/helpers';
import { 
  Zap, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  RefreshCw, 
  Copy, 
  Check, 
  ExternalLink, 
  Building2, 
  ArrowUpRight,
  Radio,
  Receipt,
  User
} from 'lucide-react';

interface LastPayoutMiniDashboardProps {
  onOpenTracker?: () => void;
  className?: string;
}

export default function LastPayoutMiniDashboard({
  onOpenTracker,
  className = '',
}: LastPayoutMiniDashboardProps) {
  const [lastTicket, setLastTicket] = useState<CashoutTicket | null>(null);
  const [ticketCount, setTicketCount] = useState<number>(0);
  const [copiedId, setCopiedId] = useState(false);
  const [lastPolledAt, setLastPolledAt] = useState<Date>(new Date());
  const [isManualRefreshing, setIsManualRefreshing] = useState(false);

  // Read latest ticket from localStorage
  const checkLocalStorage = useCallback(() => {
    try {
      const raw = localStorage.getItem('borutodev_cashout_tickets');
      if (raw) {
        const parsed: CashoutTicket[] = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Sort by timestamp descending
          const sorted = [...parsed].sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
          setLastTicket(sorted[0]);
          setTicketCount(sorted.length);
        } else {
          setLastTicket(null);
          setTicketCount(0);
        }
      } else {
        setLastTicket(null);
        setTicketCount(0);
      }
    } catch (err) {
      console.warn('Error polling local ticket storage:', err);
    }
    setLastPolledAt(new Date());
  }, []);

  // Polling loop every 2 seconds + event listeners
  useEffect(() => {
    // Initial check
    checkLocalStorage();

    const interval = setInterval(() => {
      checkLocalStorage();
    }, 2000);

    const handleStorageEvent = (e: StorageEvent) => {
      if (e.key === 'borutodev_cashout_tickets') {
        checkLocalStorage();
      }
    };

    const handleCustomEvent = () => {
      checkLocalStorage();
    };

    window.addEventListener('storage', handleStorageEvent);
    window.addEventListener('payout_tickets_updated', handleCustomEvent);

    return () => {
      clearInterval(interval);
      window.removeEventListener('storage', handleStorageEvent);
      window.removeEventListener('payout_tickets_updated', handleCustomEvent);
    };
  }, [checkLocalStorage]);

  const handleManualRefresh = () => {
    setIsManualRefreshing(true);
    checkLocalStorage();
    setTimeout(() => {
      setIsManualRefreshing(false);
    }, 500);
  };

  const handleCopyTx = (tx: string) => {
    navigator.clipboard.writeText(tx);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  // Format relative elapsed time
  const getRelativeTime = (timestamp?: number) => {
    if (!timestamp) return 'Recently';
    const elapsedSeconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
    if (elapsedSeconds < 30) return 'Just now';
    if (elapsedSeconds < 60) return `${elapsedSeconds}s ago`;
    const mins = Math.floor(elapsedSeconds / 60);
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  // Determine normalized status: 'Processing' | 'Sent' | 'Failed' | 'Completed'
  const getNormalizedStatus = (status?: string): {
    label: string;
    badgeClass: string;
    icon: typeof CheckCircle2;
    stepIndex: number;
    description: string;
  } => {
    switch (status) {
      case 'processing':
      case 'verifying_game':
      case 'funds_clearing':
        return {
          label: 'Processing',
          badgeClass: 'bg-[#D4AF37]/15 border-[#D4AF37]/40 text-[#D4AF37]',
          icon: Clock,
          stepIndex: 2,
          description: 'Validating 14-day hold & dispatching group payout API',
        };
      case 'failed':
        return {
          label: 'Failed',
          badgeClass: 'bg-rose-500/15 border-rose-500/40 text-rose-400',
          icon: AlertCircle,
          stepIndex: 1,
          description: 'Payout halted. Ensure 14 days in BD STUDIO or retry',
        };
      case 'sent':
      case 'completed':
      default:
        return {
          label: 'Sent',
          badgeClass: 'bg-[#D4AF37]/15 border-[#D4AF37]/40 text-[#D4AF37]',
          icon: CheckCircle2,
          stepIndex: 4,
          description: 'Disbursed directly into player account balance',
        };
    }
  };

  const statusInfo = getNormalizedStatus(lastTicket?.status);
  const StatusIcon = statusInfo.icon;

  return (
    <div className={`bg-[#161618] border border-[#28282B] hover:border-[#71717A] rounded-[14px] p-5 sm:p-6 shadow-xl backdrop-blur-md transition-all ${className}`}>
      
      {/* Top Header with live polling indicator */}
      <div className="flex items-center justify-between flex-wrap gap-3 pb-4 border-b border-[#28282B]">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37]">
            <Radio className="w-4 h-4 text-[#D4AF37] animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-bold text-white font-['Outfit',sans-serif]">
                Last Payout Request Status
              </h3>
              <span className="inline-flex items-center gap-1 text-[10px] font-mono font-semibold text-[#D4AF37] bg-[#D4AF37]/10 border border-[#D4AF37]/30 px-2 py-0.5 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-ping" />
                <span>Live Polling</span>
              </span>
            </div>
            <p className="text-[11px] text-[#A1A1AA]">
              Synced from local storage • Polled every 2s ({lastPolledAt.toLocaleTimeString()})
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleManualRefresh}
            disabled={isManualRefreshing}
            className="p-1.5 bg-[#101012] border border-[#28282B] hover:border-[#71717A] text-[#A1A1AA] hover:text-[#D4AF37] rounded-xl transition cursor-pointer text-xs flex items-center gap-1 font-semibold"
            title="Poll storage now"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isManualRefreshing ? 'animate-spin text-[#D4AF37]' : ''}`} />
            <span className="hidden sm:inline">Poll Now</span>
          </button>

          {onOpenTracker && (
            <button
              onClick={onOpenTracker}
              className="px-3 py-1.5 bg-[#101012] hover:bg-[#28282B] border border-[#28282B] text-white rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
            >
              <Receipt className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>All History ({ticketCount})</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      {lastTicket ? (
        <div className="pt-4 space-y-4">
          {/* Status & Recipient Hero Row */}
          <div className="flex items-center justify-between flex-wrap gap-3 bg-[#101012] border border-[#28282B] rounded-xl p-4">
            <div className="flex items-center gap-3.5">
              <img
                src={lastTicket.avatarUrl || generateRobloxAvatarUrl(lastTicket.username)}
                alt={lastTicket.username}
                className="w-12 h-12 rounded-xl bg-[#161618] border border-[#D4AF37]/40 object-cover shadow-sm"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = generateRobloxAvatarUrl(lastTicket.username);
                }}
              />
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-bold text-white">@{lastTicket.username}</span>
                  <span className="text-[11px] font-mono text-[#D4AF37] bg-[#161618] px-2 py-0.5 rounded border border-[#28282B]">
                    {lastTicket.id}
                  </span>
                </div>
                <div className="text-xs text-[#A1A1AA] flex items-center gap-1.5 mt-0.5">
                  <Building2 className="w-3 h-3 text-[#D4AF37]" />
                  <span>{lastTicket.groupName || 'BD STUDIO (#36092915)'}</span>
                  <span className="text-[#28282B]">•</span>
                  <span className="text-[#71717A]">{getRelativeTime(lastTicket.timestamp)}</span>
                </div>
              </div>
            </div>

            {/* Status Badge & Amount */}
            <div className="flex flex-col items-end gap-1">
              <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black uppercase tracking-wider border shadow-xs ${statusInfo.badgeClass}`}>
                <StatusIcon className={`w-3.5 h-3.5 ${statusInfo.label === 'Processing' ? 'animate-spin' : ''}`} />
                <span>{statusInfo.label}</span>
              </div>
              <div className="text-xl sm:text-2xl font-black font-['Outfit',sans-serif] text-[#D4AF37] font-mono">
                +{formatNumber(lastTicket.robuxAmount)} <span className="text-xs text-[#A1A1AA] font-sans font-bold">R$</span>
              </div>
            </div>
          </div>

          {/* 4-Step Progress Track */}
          <div className="bg-[#101012] border border-[#28282B] rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between text-[11px] font-semibold text-[#A1A1AA]">
              <span>Payout Fulfillment Pipeline</span>
              <span className="text-[#D4AF37]">
                {statusInfo.description}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-2 text-center text-[10px] font-bold">
              <div className="space-y-1">
                <div className="h-1.5 w-full bg-[#D4AF37] rounded-full" />
                <span className="text-[#D4AF37] block truncate">1. Submitted</span>
              </div>
              <div className="space-y-1">
                <div className={`h-1.5 w-full rounded-full ${statusInfo.stepIndex >= 2 ? 'bg-[#D4AF37]' : 'bg-[#28282B]'}`} />
                <span className={statusInfo.stepIndex >= 2 ? 'text-[#D4AF37] block truncate' : 'text-[#71717A] block truncate'}>
                  2. Hold Verified
                </span>
              </div>
              <div className="space-y-1">
                <div className={`h-1.5 w-full rounded-full ${statusInfo.stepIndex >= 3 ? 'bg-[#D4AF37]' : statusInfo.stepIndex === 2 ? 'bg-[#D4AF37] animate-pulse' : 'bg-[#28282B]'}`} />
                <span className={statusInfo.stepIndex >= 3 ? 'text-[#D4AF37] block truncate' : statusInfo.stepIndex === 2 ? 'text-[#D4AF37] block truncate' : 'text-[#71717A] block truncate'}>
                  3. Vault Dispatched
                </span>
              </div>
              <div className="space-y-1">
                <div className={`h-1.5 w-full rounded-full ${statusInfo.stepIndex >= 4 ? 'bg-[#D4AF37]' : 'bg-[#28282B]'}`} />
                <span className={statusInfo.stepIndex >= 4 ? 'text-[#D4AF37] block truncate' : 'text-[#71717A] block truncate'}>
                  4. Robux in Balance
                </span>
              </div>
            </div>
          </div>

          {/* Transaction Metadata & Fast Copy Bar */}
          <div className="flex items-center justify-between flex-wrap gap-2 text-xs text-[#A1A1AA] bg-[#101012] p-3 rounded-xl border border-[#28282B]">
            <div className="flex items-center gap-2 overflow-hidden">
              <span className="text-[#71717A] shrink-0">Payout Tx ID:</span>
              <span className="font-mono font-bold text-[#D4AF37] truncate">
                {lastTicket.payoutTxId || 'tx_rbx_auto_group_vault'}
              </span>
              <button
                onClick={() => handleCopyTx(lastTicket.payoutTxId || lastTicket.id)}
                className="text-[#A1A1AA] hover:text-white p-1 rounded hover:bg-[#28282B] cursor-pointer shrink-0 transition"
                title="Copy ID"
              >
                {copiedId ? <Check className="w-3.5 h-3.5 text-[#D4AF37]" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            <div className="flex items-center gap-3">
              <a
                href="https://www.roblox.com/communities/36092915/BD-STUDIO#!/about"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#D4AF37] hover:underline flex items-center gap-1 font-semibold transition"
              >
                <span>BD STUDIO Vault</span>
                <ExternalLink className="w-3 h-3" />
              </a>

              {onOpenTracker && (
                <button
                  onClick={onOpenTracker}
                  className="text-white hover:text-[#D4AF37] flex items-center gap-1 font-semibold cursor-pointer transition"
                >
                  <span>Receipt Details</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Empty State */
        <div className="py-8 px-4 text-center space-y-3">
          <div className="w-12 h-12 rounded-xl bg-[#101012] border border-[#28282B] mx-auto flex items-center justify-center text-[#71717A]">
            <User className="w-6 h-6 text-[#71717A]" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">No Previous Payout In Storage</h4>
            <p className="text-xs text-[#A1A1AA] max-w-sm mx-auto mt-1">
              Submit your Roblox username and desired Robux amount in the form above. The mini dashboard will instantly poll and track your automated payout in real time.
            </p>
          </div>
          <div className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#D4AF37] bg-[#D4AF37]/10 border border-[#D4AF37]/20 px-3 py-1 rounded-full">
            <Zap className="w-3 h-3 fill-[#D4AF37]" />
            <span>Ready for Instant Group Disbursals</span>
          </div>
        </div>
      )}
    </div>
  );
}
