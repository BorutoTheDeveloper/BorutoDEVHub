import { useState, useEffect } from 'react';
import { CashoutTicket } from '../types';
import { formatNumber } from '../utils/helpers';
import { 
  X, 
  Search, 
  Receipt, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  Zap, 
  Copy, 
  Check, 
  ExternalLink,
  ArrowLeft,
  RotateCcw,
  Sparkles
} from 'lucide-react';

interface CashoutTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  tickets: CashoutTicket[];
}

const CASHOUT_STEPS = [
  { id: 'pending', label: 'Request Queued', stepNumber: 1 },
  { id: 'verifying', label: '14-Day Hold Verified', stepNumber: 2 },
  { id: 'processing', label: 'Disbursing Group Funds', stepNumber: 3 },
  { id: 'completed', label: 'Robux Deposited', stepNumber: 4 },
];

function getStepIndex(status: string): number {
  switch (status) {
    case 'pending':
      return 0;
    case 'verifying':
      return 1;
    case 'processing':
      return 2;
    case 'completed':
    default:
      return 3;
  }
}

export default function CashoutTrackerModal({ isOpen, onClose, tickets }: CashoutTrackerModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filteredTickets = tickets.filter((t) =>
    t.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (t.destination && t.destination.toLowerCase().includes(searchQuery.toLowerCase())) ||
    (t.payoutTxId && t.payoutTxId.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleCopy = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div 
        className="bg-[#161618] border border-[#28282B] rounded-[14px] max-w-2xl w-full p-5 sm:p-7 shadow-2xl space-y-5 animate-in zoom-in-95 duration-150 my-6 relative max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Top Header with prominent Close Controls */}
        <div className="flex items-center justify-between border-b border-[#28282B] pb-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] shadow-xs">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-black font-['Outfit',sans-serif] text-white flex items-center gap-2">
                <span>Payout History & Tracker</span>
                <span className="text-xs font-mono font-bold bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30 px-2 py-0.5 rounded-full">
                  {tickets.length} {tickets.length === 1 ? 'Record' : 'Records'}
                </span>
              </h3>
              <p className="text-xs text-[#A1A1AA]">
                Automated group disbursements from BD STUDIO (#36092915)
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#101012] hover:bg-[#28282B] text-[#A1A1AA] hover:text-white border border-[#28282B] font-bold text-xs transition cursor-pointer shadow-md"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
            <span>Close</span>
          </button>
        </div>

        {/* Search Input */}
        <div className="relative shrink-0">
          <Search className="w-4 h-4 text-[#71717A] absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Ticket ID (e.g. CSH-8491), Roblox Username, or Tx ID..."
            className="w-full bg-[#101012] border border-[#28282B] hover:border-[#71717A] focus:border-[#D4AF37] rounded-xl pl-10 pr-4 py-3 text-xs text-white placeholder-[#71717A] focus:outline-hidden font-medium transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-3 text-xs text-[#71717A] hover:text-white"
            >
              Clear
            </button>
          )}
        </div>

        {/* Tickets Scrollable List */}
        <div className="space-y-4 overflow-y-auto pr-1 flex-1 min-h-[220px]">
          {filteredTickets.length === 0 ? (
            <div className="text-center py-12 px-4 bg-[#101012] rounded-xl border border-[#28282B] space-y-3">
              <Receipt className="w-10 h-10 text-[#71717A] mx-auto" />
              <div className="text-sm font-bold text-[#A1A1AA]">
                {searchQuery ? 'No matching payout records found' : 'No payout history yet'}
              </div>
              <p className="text-xs text-[#71717A] max-w-sm mx-auto">
                {searchQuery 
                  ? 'Try searching by a different username or transaction ID.'
                  : 'Submit a Robux cashout request to see your automated disbursement receipt here.'}
              </p>
              <button
                onClick={onClose}
                className="mt-2 px-4 py-2 bg-[#D4AF37] hover:bg-[#c49f2e] text-[#0A0A0C] font-bold text-xs rounded-xl transition cursor-pointer inline-flex items-center gap-1.5"
              >
                <Zap className="w-3.5 h-3.5 fill-[#0A0A0C]" />
                <span>Go to Cashout Portal</span>
              </button>
            </div>
          ) : (
            filteredTickets.map((ticket) => {
              const stepIdx = getStepIndex(ticket.status);
              const isCompleted = ticket.status === 'completed';

              return (
                <div
                  key={ticket.id}
                  className="bg-[#101012] border border-[#28282B] hover:border-[#71717A] rounded-xl p-4 sm:p-5 space-y-3.5 transition shadow-md"
                >
                  {/* Top Bar */}
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-3">
                      {ticket.avatarUrl ? (
                        <img
                          src={ticket.avatarUrl}
                          alt={ticket.username}
                          className="w-10 h-10 rounded-xl bg-[#161618] border border-[#D4AF37]/40 object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/20 text-[#D4AF37] flex items-center justify-center font-bold">
                          {ticket.username.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div>
                        <div className="text-sm font-bold text-white flex items-center gap-1.5">
                          <span>@{ticket.username}</span>
                          <span className="text-[11px] text-[#71717A] font-mono">({ticket.date})</span>
                        </div>
                        <div className="text-xs text-[#A1A1AA] flex items-center gap-1">
                          <span>ID:</span>
                          <span className="font-mono text-[#D4AF37] font-bold">{ticket.id}</span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-base font-black font-mono text-[#D4AF37]">
                        +{formatNumber(ticket.robuxAmount)} R$
                      </div>
                      <div className="text-[10px] text-[#71717A]">
                        {isCompleted ? 'Disbursed via Group' : 'Processing'}
                      </div>
                    </div>
                  </div>

                  {/* 4-Step Progress Bar */}
                  <div className="space-y-1.5 bg-[#161618] p-3 rounded-xl border border-[#28282B]">
                    <div className="flex justify-between text-[11px] font-semibold text-[#A1A1AA]">
                      <span className="flex items-center gap-1">
                        {isCompleted ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                        ) : (
                          <Clock className="w-3.5 h-3.5 text-[#D4AF37] animate-spin" />
                        )}
                        <span>Status: <strong className={isCompleted ? 'text-[#D4AF37] uppercase' : 'text-[#D4AF37]'}>{ticket.status}</strong></span>
                      </span>
                      <span className="font-mono text-[#71717A]">{stepIdx + 1} / 4</span>
                    </div>

                    <div className="w-full bg-[#0A0A0C] h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-[#D4AF37] h-full transition-all duration-300"
                        style={{ width: `${((stepIdx + 1) / 4) * 100}%` }}
                      />
                    </div>

                    <div className="grid grid-cols-4 gap-1 text-[9px] sm:text-[10px] text-[#71717A] text-center pt-0.5">
                      {CASHOUT_STEPS.map((step, idx) => (
                        <div
                          key={step.id}
                          className={`truncate ${idx <= stepIdx ? 'text-[#D4AF37] font-bold' : 'text-[#71717A]'}`}
                        >
                          {step.label}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs bg-[#161618] p-2.5 rounded-xl border border-[#28282B]">
                    <div>
                      <span className="text-[#71717A] text-[10px] uppercase font-semibold block">Source</span>
                      <span className="font-bold text-white truncate block">BD STUDIO #36092915</span>
                    </div>
                    <div>
                      <span className="text-[#71717A] text-[10px] uppercase font-semibold block">Fulfillment</span>
                      <span className="font-semibold text-[#D4AF37] truncate block">Instant (~1s)</span>
                    </div>
                    <div className="col-span-2 sm:col-span-1">
                      <span className="text-[#71717A] text-[10px] uppercase font-semibold block">Method</span>
                      <span className="font-mono text-[#A1A1AA] truncate block">Group Payout API</span>
                    </div>
                  </div>

                  {/* Tx & Copy Footer */}
                  <div className="flex items-center justify-between flex-wrap gap-2 pt-1 text-xs text-[#A1A1AA] bg-[#161618] p-2 rounded-xl border border-[#28282B]">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="text-[11px] text-[#71717A] font-medium">Tx ID:</span>
                      <span className="font-mono text-[11px] text-[#D4AF37] truncate max-w-[160px] sm:max-w-[220px]">
                        {ticket.payoutTxId || 'tx_rbx_auto'}
                      </span>
                      <button
                        onClick={() => handleCopy(ticket.payoutTxId || 'tx_rbx_auto')}
                        title="Copy Tx ID"
                        className="text-[#A1A1AA] hover:text-white flex items-center gap-1 font-semibold px-2 py-1 rounded-md bg-[#101012] hover:bg-[#28282B] transition cursor-pointer text-[11px] shrink-0"
                      >
                        {copiedId === (ticket.payoutTxId || 'tx_rbx_auto') ? (
                          <>
                            <Check className="w-3 h-3 text-[#D4AF37]" />
                            <span className="text-[#D4AF37]">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3 text-[#71717A]" />
                            <span>Copy Tx</span>
                          </>
                        )}
                      </button>
                    </div>

                    <button
                      onClick={() => handleCopy(ticket.id)}
                      title="Copy Ticket ID"
                      className="text-[#A1A1AA] hover:text-white flex items-center gap-1 font-semibold px-2.5 py-1 rounded-md bg-[#101012] hover:bg-[#28282B] transition cursor-pointer text-[11px] shrink-0"
                    >
                      {copiedId === ticket.id ? (
                        <>
                          <Check className="w-3 h-3 text-[#D4AF37]" />
                          <span className="text-[#D4AF37]">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3 text-[#71717A]" />
                          <span>Copy ID</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Actions with big Close / Back to Cashout Button */}
        <div className="border-t border-[#28282B] pt-3 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-[#A1A1AA]">
            <ShieldCheck className="w-4 h-4 text-[#D4AF37] shrink-0" />
            <span>Automated ledger synced with Roblox Group API.</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#101012] hover:bg-[#28282B] text-white font-semibold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 border border-[#28282B] shadow-md whitespace-nowrap"
          >
            <ArrowLeft className="w-4 h-4 text-[#71717A]" />
            <span>Close Modal</span>
          </button>
        </div>

      </div>
    </div>
  );
}
