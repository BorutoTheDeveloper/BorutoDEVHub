import { X, ShieldCheck, FileText, CheckCircle2, Zap } from 'lucide-react';

interface PolicyModalProps {
  type: 'terms' | 'privacy' | 'refund' | null;
  onClose: () => void;
}

export default function PolicyModal({ type, onClose }: PolicyModalProps) {
  if (!type) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#161618] border border-[#28282B] rounded-[14px] max-w-2xl w-full p-6 sm:p-8 shadow-2xl space-y-5 animate-in zoom-in-95 duration-150 my-8">
        <div className="flex items-center justify-between border-b border-[#28282B] pb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37]">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-lg font-black font-['Outfit',sans-serif] text-white">
                {type === 'terms' && 'Terms of Service'}
                {type === 'privacy' && 'Privacy & Account Safety Policy'}
                {type === 'refund' && '100% Automated Delivery Guarantee'}
              </h3>
              <p className="text-xs text-[#A1A1AA]">BorutoDEV Hub Group Payout Policy</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-[#A1A1AA] hover:text-white p-1 rounded-lg bg-[#101012] hover:bg-[#28282B] border border-[#28282B] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="max-h-96 overflow-y-auto pr-2 space-y-4 text-xs text-[#A1A1AA] leading-relaxed">
          {type === 'refund' && (
            <>
              <div className="bg-[#101012] border border-[#D4AF37]/30 rounded-xl p-4 text-[#A1A1AA] space-y-1">
                <div className="font-bold text-sm text-[#D4AF37] flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" /> Automated Delivery Guarantee
                </div>
                <p>
                  Every payout request on BorutoDEV Hub is executed automatically via official Roblox Group Payout APIs from BD STUDIO (#36092915) straight to your Roblox account balance.
                </p>
              </div>

              <h4 className="font-bold text-sm text-white">1. Group Payout Fulfillment</h4>
              <p>
                Robux deliveries are executed automatically via official Roblox Group Payouts. Once your 14-day BD STUDIO group requirement is cleared, delivery completes instantaneously.
              </p>

              <h4 className="font-bold text-sm text-white">2. 14-Day Roblox Hold Period</h4>
              <p>
                If a user requests a payout before completing the Roblox-enforced 14-day group membership holding period, the request remains queued in our system and will disburse upon reaching day 14.
              </p>

              <h4 className="font-bold text-sm text-white">3. Support Assistance</h4>
              <p>
                For assistance regarding group status or payout queue verification, open a support ticket on our official Discord server.
              </p>
            </>
          )}

          {type === 'terms' && (
            <>
              <h4 className="font-bold text-sm text-white">1. Acceptance of Terms</h4>
              <p>
                By accessing BorutoDEV Hub, you agree to abide by these terms and conditions. BorutoDEV Hub provides automated digital group fund disbursement services.
              </p>

              <h4 className="font-bold text-sm text-white">2. Roblox Group Payouts & Compliance</h4>
              <p>
                All transfers are performed through legitimate Roblox group payouts from BD STUDIO (#36092915). BorutoDEV Hub never requests, stores, or accesses user account passwords, emails, session cookies, or private sensitive Roblox credentials.
              </p>

              <h4 className="font-bold text-sm text-white">3. Disclaimer & Trademarks</h4>
              <p>
                BorutoDEV Hub is an independent platform and is not affiliated with, authorized, maintained, sponsored or endorsed by Roblox Corporation or any of its affiliates. "Roblox" and "Robux" are registered trademarks of Roblox Corporation.
              </p>
            </>
          )}

          {type === 'privacy' && (
            <>
              <h4 className="font-bold text-sm text-white">1. Zero-Credential Guarantee</h4>
              <p>
                We value your account safety. We will NEVER ask for your password, email, cookies, pin, or private login credentials. Only your public Roblox username is used to identify your account in our group payout system.
              </p>

              <h4 className="font-bold text-sm text-white">2. Account Security</h4>
              <p>
                Transactions are handled through the official Roblox Economy group payout engine. Your account security remains 100% safeguarded at all times.
              </p>

              <h4 className="font-bold text-sm text-white">3. Data Retention</h4>
              <p>
                Transaction IDs and Roblox usernames are kept solely for the purpose of tracking payout status and group verification.
              </p>
            </>
          )}
        </div>

        <div className="pt-2 border-t border-[#28282B] flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-[#101012] hover:bg-[#28282B] text-white text-xs font-bold rounded-xl border border-[#28282B] transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
