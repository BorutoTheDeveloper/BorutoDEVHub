import { MessageSquare, Bell, Gift, Headphones, ExternalLink, ShieldCheck } from 'lucide-react';

export default function DiscordBanner() {
  return (
    <section className="py-10 relative bg-[#0A0A0C]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-[14px] bg-[#161618] border border-[#28282B] p-6 sm:p-10 shadow-2xl">
          {/* Ambient Glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-[#D4AF37]/5 blur-[90px] pointer-events-none rounded-full" />

          <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="space-y-4 max-w-xl text-center lg:text-left">
              <div className="inline-flex items-center gap-2 bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30 px-3 py-1 rounded-full text-xs font-bold">
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Join 12,450+ Roblox Players</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-black font-['Outfit',sans-serif] text-white">
                Join the Official BorutoDEV Hub Discord
              </h3>

              <p className="text-xs sm:text-sm text-[#A1A1AA] leading-relaxed">
                Get instant restock pings, participate in weekly free Robux giveaways, track live group payouts, and access 24/7 dedicated ticket support.
              </p>

              <div className="grid grid-cols-3 gap-2 pt-2 text-center sm:text-left">
                <div className="bg-[#101012] border border-[#28282B] rounded-xl p-2.5">
                  <Bell className="w-4 h-4 text-[#D4AF37] mb-1 mx-auto sm:mx-0" />
                  <div className="text-[11px] font-bold text-white">Restock Alerts</div>
                  <div className="text-[9px] text-[#71717A]">Instant notifications</div>
                </div>

                <div className="bg-[#101012] border border-[#28282B] rounded-xl p-2.5">
                  <Gift className="w-4 h-4 text-[#D4AF37] mb-1 mx-auto sm:mx-0" />
                  <div className="text-[11px] font-bold text-white">Free Giveaways</div>
                  <div className="text-[9px] text-[#71717A]">Weekly Robux drops</div>
                </div>

                <div className="bg-[#101012] border border-[#28282B] rounded-xl p-2.5">
                  <Headphones className="w-4 h-4 text-white mb-1 mx-auto sm:mx-0" />
                  <div className="text-[11px] font-bold text-white">24/7 Support</div>
                  <div className="text-[9px] text-[#71717A]">Live ticket staff</div>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center gap-3 shrink-0">
              <a
                href="https://discord.gg/borutodev"
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 bg-[#D4AF37] hover:bg-[#c49f2e] text-[#0A0A0C] font-black text-sm rounded-xl shadow-xl shadow-[#D4AF37]/20 transition-all transform hover:-translate-y-0.5 flex items-center gap-2 cursor-pointer"
              >
                <MessageSquare className="w-5 h-5 fill-[#0A0A0C]" />
                <span>Join Discord Server</span>
                <ExternalLink className="w-4 h-4 text-[#0A0A0C]" />
              </a>
              <span className="text-[11px] text-[#71717A]">1,820+ online right now</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
