import { Users, UserCheck, Zap, ShieldCheck, KeyRound, Sparkles, SendHorizontal } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      step: '01',
      title: 'User Identification',
      icon: Users,
      desc: 'The system queries the public Roblox API using your account username to retrieve your permanent, unique Roblox User ID and profile avatar.',
      color: 'text-[#D4AF37]',
      bg: 'bg-[#D4AF37]/10 border-[#D4AF37]/20',
      speed: 'Instant Lookup',
    },
    {
      step: '02',
      title: 'Passwordless Authentication',
      icon: KeyRound,
      desc: 'To prove account ownership without sensitive credentials (no passwords, cookies, or 2FA codes), the portal generates a temporary 5-word string you paste into your Roblox bio.',
      color: 'text-[#D4AF37]',
      bg: 'bg-[#D4AF37]/10 border-[#D4AF37]/20',
      speed: 'Zero Passwords',
    },
    {
      step: '03',
      title: 'Balance Reconciliation',
      icon: Sparkles,
      desc: 'The backend cross-references your verified User ID against historical donation ledgers from previous Simply PLS DONATE game builds to calculate accumulated unpaid Robux.',
      color: 'text-[#D4AF37]',
      bg: 'bg-[#D4AF37]/10 border-[#D4AF37]/20',
      speed: 'Ledger Audit',
    },
    {
      step: '04',
      title: 'Automated Delivery',
      icon: Zap,
      desc: 'Confirmed balances are dispatched directly to your Roblox account balance using BD STUDIO (#36092915) automated group disbursements in approximately two minutes.',
      color: 'text-[#D4AF37]',
      bg: 'bg-[#D4AF37]/10 border-[#D4AF37]/20',
      speed: '~2 Minutes',
    },
  ];

  return (
    <section className="py-14 relative border-t border-[#28282B] bg-[#0A0A0C]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 text-[#D4AF37] font-bold text-xs uppercase tracking-wider bg-[#D4AF37]/10 border border-[#D4AF37]/20 px-3.5 py-1.5 rounded-full mb-3 shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Behind The Scenes Workflow</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black font-['Outfit',sans-serif] text-white">
            How the System Works Behind the Scenes
          </h2>
          <p className="text-sm text-[#A1A1AA] mt-2">
            Automated verification and disbursement architecture powered by public Roblox APIs and BD STUDIO group payout ledgers.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 relative">
          {steps.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.step}
                className="bg-[#161618] border border-[#28282B] rounded-[14px] p-6 relative hover:border-[#D4AF37]/40 transition flex flex-col justify-between shadow-lg"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${item.bg}`}>
                      <Icon className={`w-6 h-6 ${item.color}`} />
                    </div>
                    <span className="text-2xl font-black font-['Outfit',sans-serif] text-[#28282B]">
                      {item.step}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-xs text-[#A1A1AA] leading-relaxed">{item.desc}</p>
                </div>

                <div className="pt-4 mt-4 border-t border-[#28282B] flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-[#A1A1AA] flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]"></span>
                    {item.speed}
                  </span>
                  <span className="text-[#D4AF37] font-mono font-bold">100% Free</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
