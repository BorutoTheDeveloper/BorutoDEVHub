import { useState, useEffect } from 'react';
import PandaLogo from './PandaLogo';
import { 
  Receipt, 
  Sparkles, 
  ShieldCheck, 
  Zap, 
  TrendingUp, 
  HelpCircle, 
  Menu, 
  X,
  ExternalLink
} from 'lucide-react';
import { fetchRobloxGroup, formatNumber } from '../utils/helpers';

interface NavbarProps {
  onOpenTracker: () => void;
  onOpenChecker: () => void;
  onOpenRates: () => void;
  onOpenStock: () => void;
  onOpenFaq: () => void;
  onOpenCashout: () => void;
  ticketCount: number;
}

export default function Navbar({
  onOpenTracker,
  onOpenChecker,
  onOpenRates,
  onOpenStock,
  onOpenFaq,
  onOpenCashout,
  ticketCount,
}: NavbarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [vaultStock, setVaultStock] = useState<number>(580000);

  useEffect(() => {
    fetchRobloxGroup(36092915).then((g) => {
      if (g && g.stock) setVaultStock(g.stock);
    });
  }, []);

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0A0A0C]/95 backdrop-blur-md border-b border-[#28282B] transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Brand */}
        <div 
          onClick={() => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }} 
          className="cursor-pointer"
        >
          <PandaLogo />
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-1.5">
          <button
            onClick={onOpenCashout}
            className="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-bold text-[#D4AF37] bg-[#D4AF37]/10 hover:bg-[#D4AF37]/20 border border-[#D4AF37]/30 transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Zap className="w-3.5 h-3.5 fill-[#D4AF37]" />
            <span>Robux Cashout</span>
          </button>

          <button
            onClick={onOpenChecker}
            className="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium text-[#A1A1AA] hover:text-white hover:bg-[#161618] transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>14-Day Checker</span>
          </button>

          <button
            onClick={onOpenStock}
            className="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium text-[#A1A1AA] hover:text-white hover:bg-[#161618] transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <TrendingUp className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Vault & History</span>
          </button>

          <button
            onClick={onOpenFaq}
            className="px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium text-[#A1A1AA] hover:text-white hover:bg-[#161618] transition flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <HelpCircle className="w-3.5 h-3.5 text-[#71717A]" />
            <span>FAQ</span>
          </button>
        </nav>

        {/* Right Action Tools */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Live Vault Badge */}
          <div 
            onClick={onOpenStock}
            className="hidden sm:flex items-center gap-2 bg-[#161618] border border-[#28282B] hover:border-[#D4AF37]/40 rounded-xl px-3 py-1.5 text-xs font-semibold text-[#A1A1AA] transition shadow-xs cursor-pointer whitespace-nowrap"
          >
            <span className="w-2 h-2 rounded-full bg-[#D4AF37] animate-pulse" />
            <span className="text-[#71717A] font-mono">Vault:</span>
            <span className="font-mono font-bold text-[#D4AF37]">{formatNumber(vaultStock)} R$</span>
          </div>

          {/* Cashout Tickets Modal Trigger */}
          <button
            id="order-tracker-nav-btn"
            onClick={onOpenTracker}
            className="relative flex items-center gap-1.5 bg-[#161618] hover:bg-[#1C1C1F] border border-[#28282B] text-[#A1A1AA] hover:text-white px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap"
          >
            <Receipt className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>My Payouts</span>
            {ticketCount > 0 && (
              <span className="bg-[#D4AF37] text-[#0A0A0C] font-black rounded-full text-[10px] w-4 h-4 flex items-center justify-center -ml-0.5">
                {ticketCount}
              </span>
            )}
          </button>

          {/* Official Roblox Group Link */}
          <a
            href="https://www.roblox.com/communities/36092915/BD-STUDIO#!/about"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden lg:flex items-center gap-1.5 bg-[#161618] hover:bg-[#1C1C1F] border border-[#28282B] text-[#A1A1AA] hover:text-white px-3 py-1.5 rounded-xl text-xs font-semibold transition whitespace-nowrap"
          >
            <span>BD STUDIO</span>
            <ExternalLink className="w-3.5 h-3.5 text-[#D4AF37]" />
          </a>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-[#71717A] hover:text-white bg-[#161618] border border-[#28282B] rounded-xl"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-[#0A0A0C] border-b border-[#28282B] px-4 py-4 space-y-2 animate-in slide-in-from-top-4 duration-200">
          <button
            onClick={() => {
              onOpenCashout();
              setIsMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2.5 rounded-xl text-sm font-bold text-[#D4AF37] bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center gap-2"
          >
            <Zap className="w-4 h-4" />
            <span>Robux Payout Portal</span>
          </button>

          <button
            onClick={() => {
              onOpenChecker();
              setIsMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-xl text-sm font-semibold text-[#A1A1AA] hover:bg-[#161618] flex items-center gap-2"
          >
            <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
            <span>14-Day Group Checker</span>
          </button>

          <button
            onClick={() => {
              onOpenStock();
              setIsMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-xl text-sm font-semibold text-[#A1A1AA] hover:bg-[#161618] flex items-center gap-2"
          >
            <TrendingUp className="w-4 h-4 text-[#D4AF37]" />
            <span>BD STUDIO Vault</span>
          </button>

          <button
            onClick={() => {
              onOpenRates();
              setIsMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-xl text-sm font-semibold text-[#A1A1AA] hover:bg-[#161618] flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-[#D4AF37]" />
            <span>Payout Tiers</span>
          </button>

          <button
            onClick={() => {
              onOpenFaq();
              setIsMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2 rounded-xl text-sm font-semibold text-[#A1A1AA] hover:bg-[#161618] flex items-center gap-2"
          >
            <HelpCircle className="w-4 h-4 text-[#71717A]" />
            <span>FAQ</span>
          </button>
        </div>
      )}
    </header>
  );
}
