import { useState } from 'react';
import { formatNumber } from '../utils/helpers';
import { 
  Sparkles, 
  ArrowRight, 
  Check, 
  X, 
  ShieldCheck, 
  Zap, 
  Coins,
  SendHorizontal
} from 'lucide-react';

interface CashoutRatesSectionProps {
  onSelectAmountForCashout: (amount: number) => void;
}

export default function CashoutRatesSection({
  onSelectAmountForCashout,
}: CashoutRatesSectionProps) {
  const [calcRobuxStr, setCalcRobuxStr] = useState<string>('');

  const robuxAmount = Number(calcRobuxStr) || 0;

  // Preset tiers
  const rateTiers = [
    { robux: 1, label: '1 R$', tag: 'Micro' },
    { robux: 1000, label: '1,000 R$', tag: 'Starter' },
    { robux: 5000, label: '5,000 R$', tag: 'Popular' },
    { robux: 10000, label: '10,000 R$', tag: 'Most Claimed' },
    { robux: 25000, label: '25,000 R$', tag: 'Creator' },
    { robux: 50000, label: '50,000 R$', tag: 'Studio Tier' },
  ];

  return (
    <section id="rates-section" className="py-14 relative border-t border-[#28282B]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 text-[#D4AF37] font-bold text-xs uppercase tracking-wider bg-[#D4AF37]/10 border border-[#D4AF37]/20 px-3.5 py-1.5 rounded-full mb-3 shadow-xs">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Automated Group Distribution</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black font-['Outfit',sans-serif] text-white">
            Robux Auto-Payout Tiers & Calculator
          </h2>
          <p className="text-sm text-[#A1A1AA] mt-2">
            Instant automated disbursement from BD STUDIO (#36092915) directly into your player balance.
          </p>
        </div>

        {/* 2-Column Calculator & Comparison */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Interactive Calculator (7 Cols) */}
          <div className="lg:col-span-7 bg-[#161618] border border-[#28282B] rounded-[14px] p-6 sm:p-8 space-y-6 shadow-xl">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#28282B]">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Coins className="w-5 h-5 text-[#D4AF37]" />
                  <span>Choose Robux to Disburse</span>
                </h3>
                <p className="text-xs text-[#A1A1AA]">Type or drag the slider to adjust payout volume</p>
              </div>

              <div className="flex items-center gap-2 bg-[#101012] border border-[#28282B] rounded-xl px-4 py-2 self-start sm:self-auto min-w-[200px]">
                <input
                  type="text"
                  inputMode="numeric"
                  placeholder="Enter amount"
                  value={calcRobuxStr}
                  onChange={(e) => setCalcRobuxStr(e.target.value.replace(/[^0-9]/g, ''))}
                  className="bg-transparent text-lg sm:text-xl font-bold font-['Outfit',sans-serif] text-[#D4AF37] w-full focus:outline-hidden placeholder:text-[#52525B] placeholder:text-sm placeholder:font-normal"
                />
                <span className="text-xs font-bold text-[#71717A] uppercase shrink-0">R$</span>
              </div>
            </div>

            {/* Slider */}
            <div className="space-y-2">
              <input
                type="range"
                min={1}
                max={100000}
                step={500}
                value={Math.min(100000, robuxAmount || 1)}
                onChange={(e) => setCalcRobuxStr(e.target.value)}
                className="w-full h-2.5 bg-[#101012] rounded-lg appearance-none cursor-pointer accent-[#D4AF37]"
              />
              <div className="flex justify-between text-[11px] font-semibold text-[#71717A] font-mono">
                <span>1 R$</span>
                <span>25,000 R$</span>
                <span>50,000 R$</span>
                <span>100,000 R$</span>
              </div>
            </div>

            {/* Quick preset buttons */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {rateTiers.map((tier) => (
                <button
                  key={tier.robux}
                  onClick={() => setCalcRobuxStr(String(tier.robux))}
                  className={`p-2.5 rounded-xl text-center border text-xs font-bold transition cursor-pointer ${
                    robuxAmount === tier.robux
                      ? 'bg-[#D4AF37] text-[#0A0A0C] border-[#D4AF37] shadow-md'
                      : 'bg-[#101012] text-[#A1A1AA] border-[#28282B] hover:border-[#71717A]'
                  }`}
                >
                  <div>{formatNumber(tier.robux)}</div>
                  <div className={`text-[10px] font-mono ${robuxAmount === tier.robux ? 'text-[#0A0A0C] font-black' : 'text-[#D4AF37]'}`}>
                    {tier.tag}
                  </div>
                </button>
              ))}
            </div>

            {/* Result Box */}
            <div className="bg-[#101012] p-6 rounded-xl border border-[#28282B] space-y-4">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <div className="text-xs uppercase font-bold text-[#71717A]">Instant Group Payout</div>
                  <div className="text-3xl sm:text-4xl font-black font-['Outfit',sans-serif] text-[#D4AF37] mt-0.5">
                    {robuxAmount > 0 ? `+${formatNumber(robuxAmount)}` : '0'}{' '}
                    <span className="text-lg text-white">Robux</span>
                  </div>
                  <div className="text-xs font-semibold text-[#71717A] font-mono">
                    Disbursed directly via BD STUDIO (#36092915)
                  </div>
                </div>

                <button
                  onClick={() => onSelectAmountForCashout(robuxAmount || 5000)}
                  disabled={robuxAmount <= 0}
                  className="w-full sm:w-auto px-5 py-3 bg-[#D4AF37] hover:bg-[#c49f2e] disabled:opacity-50 text-[#0A0A0C] font-bold text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-[#D4AF37]/20 cursor-pointer whitespace-nowrap"
                >
                  <SendHorizontal className="w-4 h-4 text-[#0A0A0C]" />
                  <span>{robuxAmount > 0 ? `Claim ${formatNumber(robuxAmount)} R$` : 'Enter Robux Amount'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-[#28282B] text-[11px] text-[#71717A]">
                <div>
                  <span className="text-[#71717A]">Method:</span> <strong className="text-white">Group Payout</strong>
                </div>
                <div>
                  <span className="text-[#71717A]">Cost:</span> <strong className="text-[#D4AF37]">0.00 (FREE)</strong>
                </div>
                <div>
                  <span className="text-[#71717A]">Speed:</span> <strong className="text-white">~Instant</strong>
                </div>
                <div>
                  <span className="text-[#71717A]">Group:</span> <strong className="text-[#D4AF37]">BD STUDIO</strong>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Automated System Benefits (5 Cols) */}
          <div className="lg:col-span-5 bg-[#161618] border border-[#28282B] rounded-[14px] p-6 sm:p-8 space-y-5 shadow-xl">
            <div className="flex items-center gap-2 pb-2 border-b border-[#28282B]">
              <Zap className="w-5 h-5 text-[#D4AF37] fill-[#D4AF37]" />
              <h3 className="text-lg font-bold text-white">Automated Engine Advantages</h3>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-[#101012] p-3.5 rounded-xl border border-[#28282B] space-y-1.5">
                <div className="text-[#71717A] font-semibold uppercase text-[10px]">Owner Effort</div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1.5 text-[#D4AF37] font-bold">
                    <Check className="w-4 h-4 stroke-[3]" />
                    <span>100% Automated by System</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#71717A] line-through">
                    <span>Manual Payouts</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#101012] p-3.5 rounded-xl border border-[#28282B] space-y-1.5">
                <div className="text-[#71717A] font-semibold uppercase text-[10px]">Payout Speed</div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1.5 text-[#D4AF37] font-bold">
                    <Check className="w-4 h-4 stroke-[3]" />
                    <span>Instant (~Seconds)</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#71717A]">
                    <X className="w-4 h-4" />
                    <span>Waiting on Discord Admin</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#101012] p-3.5 rounded-xl border border-[#28282B] space-y-1.5">
                <div className="text-[#71717A] font-semibold uppercase text-[10px]">Player Security</div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1.5 text-[#D4AF37] font-bold">
                    <Check className="w-4 h-4 stroke-[3]" />
                    <span>Public Username Only</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#D4AF37]">
                    <ShieldCheck className="w-4 h-4" />
                    <span>100% Safe</span>
                  </div>
                </div>
              </div>

              <div className="bg-[#101012] p-3.5 rounded-xl border border-[#28282B] space-y-1.5">
                <div className="text-[#71717A] font-semibold uppercase text-[10px]">Official Group Integration</div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1.5 text-[#D4AF37] font-bold">
                    <Check className="w-4 h-4 stroke-[3]" />
                    <span>BD STUDIO (#36092915)</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-3 bg-[#101012] border border-[#28282B] rounded-xl text-[11px] text-[#A1A1AA] leading-relaxed">
              💡 <strong className="text-white">Hands-Free Automation:</strong> When players request a payout, the system automatically validates their membership and triggers the Roblox Economy payout on backend so you never have to manually click or send payouts yourself.
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
