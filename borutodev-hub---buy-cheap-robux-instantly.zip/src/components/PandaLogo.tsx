export default function PandaLogo({ 
  className = 'h-10 w-10', 
  textClassName = 'text-xl',
  showText = true 
}: { 
  className?: string; 
  textClassName?: string;
  showText?: boolean;
}) {
  return (
    <div className="flex items-center gap-3 select-none group cursor-pointer">
      <div className="relative shrink-0">
        {/* Crisp subtle ring border container */}
        <div className={`relative flex items-center justify-center rounded-[14px] bg-[#161618] border border-[#D4AF37]/50 shadow-md shadow-black/60 overflow-hidden ${className}`}>
          <img
            src="/brand-logo.webp"
            alt="BorutoDEV Hub Logo"
            className="w-full h-full object-cover block"
            loading="eager"
            referrerPolicy="no-referrer"
            onError={(e) => {
              (e.target as HTMLImageElement).src = 'https://i.ibb.co/gZrmcNLh/ard4.webp';
            }}
          />
        </div>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className={`font-['Outfit',sans-serif] font-black tracking-tight leading-none text-white ${textClassName}`}>
            BorutoDEV<span className="text-[#D4AF37]"> Hub</span>
          </div>
          <span className="text-[10px] font-bold text-[#D4AF37] uppercase tracking-widest leading-tight mt-0.5">
            Robux Cashout
          </span>
        </div>
      )}
    </div>
  );
}
