import PandaLogo from './PandaLogo';
import { ShieldCheck, MessageSquare, ExternalLink, Zap, Building2, Users } from 'lucide-react';
import { ROBOLX_GROUPS } from '../data/constants';

interface FooterProps {
  onOpenPolicy: (type: 'terms' | 'privacy' | 'refund') => void;
  onOpenRates: () => void;
  onOpenChecker: () => void;
  onOpenTracker: () => void;
}

export default function Footer({
  onOpenPolicy,
  onOpenRates,
  onOpenChecker,
  onOpenTracker,
}: FooterProps) {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const primaryGroup = ROBOLX_GROUPS[0];

  return (
    <footer className="bg-[#0A0A0C] border-t border-[#28282B] text-[#A1A1AA] text-xs pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <PandaLogo />
            <p className="text-[#A1A1AA] text-xs leading-relaxed max-w-sm">
              BorutoDEV Hub is the dedicated Automated Robux Group Payout Portal. Claim Robux directly into your player account via <strong>BD STUDIO (#36092915)</strong> with 0% fees, instant 14-day hold verification, and 100% automated disbursals.
            </p>
            <div className="flex items-center gap-3 pt-1">
              <a
                href="https://discord.gg/borutodev"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-[#161618] border border-[#28282B] flex items-center justify-center text-[#D4AF37] hover:border-[#D4AF37]/50 transition"
                aria-label="Discord"
              >
                <MessageSquare className="w-4 h-4" />
              </a>
              <div className="px-3 py-1.5 rounded-lg bg-[#161618] border border-[#D4AF37]/30 text-[#D4AF37] text-[11px] font-bold flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 fill-[#D4AF37]" />
                <span>100% Automated Group Payouts</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-sm font-['Outfit',sans-serif]">Payout Portal</h4>
            <ul className="space-y-2 text-[#A1A1AA]">
              <li>
                <button onClick={() => scrollTo('cashout-section')} className="hover:text-[#D4AF37] transition cursor-pointer text-left">
                  Claim Robux Payout
                </button>
              </li>
              <li>
                <button onClick={() => { onOpenChecker(); scrollTo('checker-section'); }} className="hover:text-[#D4AF37] transition cursor-pointer text-left">
                  14-Day Group Checker
                </button>
              </li>
              <li>
                <button onClick={() => { onOpenRates(); scrollTo('rates-section'); }} className="hover:text-[#D4AF37] transition cursor-pointer text-left">
                  Payout Tiers & Calculator
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('stock-section')} className="hover:text-[#D4AF37] transition cursor-pointer text-left">
                  BD STUDIO Vault & History
                </button>
              </li>
              <li>
                <button onClick={onOpenTracker} className="hover:text-[#D4AF37] transition cursor-pointer text-left">
                  Track Payout Request
                </button>
              </li>
            </ul>
          </div>

          {/* Official Roblox Group */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-sm font-['Outfit',sans-serif]">Roblox Group</h4>
            <ul className="space-y-2 text-[#A1A1AA]">
              <li>
                <a 
                  href={primaryGroup.link} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="hover:text-[#D4AF37] transition flex items-center gap-1 font-semibold text-white"
                >
                  <Building2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>BD STUDIO (#36092915)</span>
                  <ExternalLink className="w-3 h-3 text-[#D4AF37]" />
                </a>
              </li>
              <li>
                <a href="https://discord.gg/borutodev" target="_blank" rel="noopener noreferrer" className="hover:text-[#D4AF37] transition flex items-center gap-1">
                  <span>Discord Community & Support</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <button onClick={() => scrollTo('faq-section')} className="hover:text-[#D4AF37] transition cursor-pointer text-left">
                  14-Day Hold Rules FAQ
                </button>
              </li>
            </ul>
          </div>

          {/* Legal & Policies */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-sm font-['Outfit',sans-serif]">Security & Policies</h4>
            <ul className="space-y-2 text-[#A1A1AA]">
              <li>
                <button onClick={() => onOpenPolicy('refund')} className="hover:text-[#D4AF37] transition cursor-pointer text-left">
                  Automated Delivery Guarantee
                </button>
              </li>
              <li>
                <button onClick={() => onOpenPolicy('terms')} className="hover:text-[#D4AF37] transition cursor-pointer text-left">
                  Terms of Service
                </button>
              </li>
              <li>
                <button onClick={() => onOpenPolicy('privacy')} className="hover:text-[#D4AF37] transition cursor-pointer text-left">
                  Privacy & Account Safety
                </button>
              </li>
              <li className="pt-2 text-[11px] text-[#D4AF37] flex items-center gap-1 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Zero Account Credentials Needed</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Legal Disclaimer Box */}
        <div className="bg-[#161618] border border-[#28282B] rounded-[14px] p-4 text-[11px] text-[#71717A] leading-relaxed space-y-2">
          <p>
            <strong className="text-[#A1A1AA]">Disclaimer:</strong> BorutoDEV Hub is an independent automated group payout portal operating in accordance with Roblox group payout mechanisms. BorutoDEV Hub is not affiliated with, maintained, authorized, or sponsored by Roblox Corporation. Roblox, Robux, and all associated marks are registered trademarks of Roblox Corporation.
          </p>
          <p>
            All Robux funds are disbursed directly via official Roblox Group Payouts from BD STUDIO (#36092915) into your Roblox player balance. We will never ask for your account password, PIN, email, or private session cookies.
          </p>
        </div>

        {/* Bottom copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-[#28282B] text-[#71717A] text-[11px]">
          <div>
            © {new Date().getFullYear()} BorutoDEV Hub • Automated Robux Group Payout Portal. All rights reserved.
          </div>
          <div className="flex items-center gap-2 text-[#D4AF37] font-medium">
            <Zap className="w-3 h-3 fill-[#D4AF37]" />
            <span>Automated Payout Engine Active</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
