import { useState } from 'react';
import { FAQ_ITEMS } from '../data/constants';
import { HelpCircle, ChevronDown, Search, Shield, Zap, Clock, Coins } from 'lucide-react';

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Questions', icon: HelpCircle },
    { id: 'cashout', label: 'Payout Process', icon: Zap },
    { id: '14-day-rule', label: '14-Day Roblox Hold', icon: Clock },
    { id: 'safety', label: 'Safety & Security', icon: Shield },
    { id: 'payouts', label: 'Group Vault & Tiers', icon: Coins },
  ];

  const filteredFaqs = FAQ_ITEMS.filter((item) => {
    const matchesSearch =
      item.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <section id="faq-section" className="py-14 relative border-t border-[#28282B] bg-[#0A0A0C]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 text-[#D4AF37] font-bold text-xs uppercase tracking-wider bg-[#D4AF37]/10 border border-[#D4AF37]/20 px-3.5 py-1.5 rounded-full mb-3 shadow-xs">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Got Payout Questions?</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black font-['Outfit',sans-serif] text-white">
            Frequently Asked Questions
          </h2>
          <p className="text-sm text-[#A1A1AA] mt-2">
            Everything you need to know about automated Robux group payouts from BD STUDIO (#36092915) and 14-day hold rules.
          </p>
        </div>

        {/* Search & Category Tabs */}
        <div className="space-y-4 mb-8">
          <div className="relative">
            <Search className="w-4 h-4 text-[#71717A] absolute left-4 top-3.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search questions (e.g. 14 days, automated payout, group join, password)..."
              className="w-full bg-[#161618] border border-[#28282B] rounded-xl pl-11 pr-4 py-3 text-sm text-white placeholder-[#71717A] focus:outline-hidden focus:border-[#D4AF37]"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
            {categories.map((cat) => {
              const Icon = cat.icon;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition flex items-center gap-1.5 cursor-pointer ${
                    activeCategory === cat.id
                      ? 'bg-[#D4AF37] text-[#0A0A0C] font-bold shadow-xs'
                      : 'bg-[#161618] text-[#A1A1AA] hover:text-white border border-[#28282B]'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-3">
          {filteredFaqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className={`border rounded-[14px] transition-all overflow-hidden ${
                  isOpen
                    ? 'bg-[#161618] border-[#D4AF37]/40 shadow-lg'
                    : 'bg-[#161618] border-[#28282B] hover:border-[#71717A]'
                }`}
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full px-5 py-4 text-left flex items-center justify-between gap-4 cursor-pointer"
                >
                  <span className="font-bold text-white text-sm sm:text-base leading-snug">
                    {faq.question}
                  </span>
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 transition-transform ${
                      isOpen ? 'rotate-180 bg-[#D4AF37]/20 text-[#D4AF37]' : 'bg-[#101012] text-[#71717A]'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-4 pt-1 text-xs sm:text-sm text-[#A1A1AA] leading-relaxed border-t border-[#28282B] animate-in fade-in duration-200">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
