import { useState, useMemo } from 'react';
import { formatNumber } from '../utils/helpers';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
} from 'recharts';
import {
  TrendingUp,
  BarChart3,
  Zap,
  Calendar,
  Layers,
  ArrowUpRight,
  ShieldCheck,
  Award,
  Sparkles,
} from 'lucide-react';

export interface DailyPayoutVolumePoint {
  day: string;
  shortDate: string;
  fullDate: string;
  volume: number;
  payoutCount: number;
  avgPayout: number;
  usdValue: number;
  isPeak?: boolean;
  isToday?: boolean;
}

interface PayoutVolume7DayChartProps {
  className?: string;
}

export default function PayoutVolume7DayChart({ className = '' }: PayoutVolume7DayChartProps) {
  const [viewMode, setViewMode] = useState<'volume' | 'count' | 'combined'>('combined');
  const [hoveredDay, setHoveredDay] = useState<DailyPayoutVolumePoint | null>(null);

  // Generate dynamic 7-day rolling data ending on today's date
  const sevenDayData = useMemo<DailyPayoutVolumePoint[]>(() => {
    const data: DailyPayoutVolumePoint[] = [];
    const today = new Date();

    // Baseline daily volumes over the past 7 days (representing active BD STUDIO disbursements)
    const volumeSeeds = [42500, 56000, 48200, 68500, 74000, 61200, 53800];
    const countSeeds = [24, 31, 28, 39, 44, 35, 30];

    let maxVol = 0;
    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);

      const dayOfWeek = d.toLocaleDateString('en-US', { weekday: 'short' });
      const shortDate = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      const fullDate = d.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' });

      const seedIdx = 6 - i;
      const baseVol = volumeSeeds[seedIdx] || 50000;
      const count = countSeeds[seedIdx] || 28;
      const avg = Math.round(baseVol / count);
      const usd = Number((baseVol * 0.0035).toFixed(2));

      if (baseVol > maxVol) {
        maxVol = baseVol;
      }

      data.push({
        day: dayOfWeek,
        shortDate,
        fullDate,
        volume: baseVol,
        payoutCount: count,
        avgPayout: avg,
        usdValue: usd,
        isToday: i === 0,
      });
    }

    // Mark peak day
    return data.map(item => ({
      ...item,
      isPeak: item.volume === maxVol,
    }));
  }, []);

  // Summary statistics
  const metrics = useMemo(() => {
    const totalVolume = sevenDayData.reduce((sum, d) => sum + d.volume, 0);
    const totalTransactions = sevenDayData.reduce((sum, d) => sum + d.payoutCount, 0);
    const avgDailyVolume = Math.round(totalVolume / sevenDayData.length);
    const peakDay = sevenDayData.find(d => d.isPeak) || sevenDayData[0];
    const totalUsd = Number((totalVolume * 0.0035).toFixed(2));

    return {
      totalVolume,
      totalTransactions,
      avgDailyVolume,
      peakDay,
      totalUsd,
    };
  }, [sevenDayData]);

  // Active display point for details widget (default to today or hovered item)
  const activePoint = hoveredDay || sevenDayData[sevenDayData.length - 1];

  // Custom high-contrast Recharts tooltip
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload as DailyPayoutVolumePoint;
      return (
        <div className="bg-[#161618]/98 border border-[#D4AF37]/50 p-4 rounded-2xl shadow-2xl backdrop-blur-xl text-xs space-y-2.5 min-w-[240px] z-50">
          <div className="flex items-center justify-between border-b border-[#28282B] pb-2">
            <div className="flex items-center gap-1.5 font-bold text-white">
              <Calendar className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{data.fullDate}</span>
            </div>
            {data.isToday && (
              <span className="text-[10px] text-[#D4AF37] bg-[#D4AF37]/10 border border-[#D4AF37]/40 px-1.5 py-0.5 rounded-full font-mono font-bold">
                Today
              </span>
            )}
            {data.isPeak && !data.isToday && (
              <span className="text-[10px] text-amber-400 bg-amber-950/80 border border-amber-500/40 px-1.5 py-0.5 rounded-full font-mono font-bold flex items-center gap-1">
                <Award className="w-3 h-3" /> 7D Peak
              </span>
            )}
          </div>

          <div className="space-y-2 pt-0.5">
            <div className="flex items-center justify-between">
              <span className="text-[#A1A1AA]">Total Robux Paid:</span>
              <span className="font-mono font-black text-[#D4AF37] text-sm">
                +{formatNumber(data.volume)} R$
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-[#A1A1AA]">Completed Payouts:</span>
              <span className="font-mono font-bold text-white">
                {data.payoutCount} transactions
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-[#A1A1AA]">Avg Payout Size:</span>
              <span className="font-mono font-semibold text-[#A1A1AA]">
                ~{formatNumber(data.avgPayout)} R$
              </span>
            </div>

            <div className="flex items-center justify-between text-[11px] border-t border-[#28282B] pt-1.5">
              <span className="text-[#71717A]">Approx. USD Value:</span>
              <span className="font-mono text-[#D4AF37] font-semibold">
                ${data.usdValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className={`bg-[#161618] border border-[#28282B] hover:border-[#D4AF37]/40 rounded-[14px] p-5 sm:p-6 shadow-xl transition-all ${className}`}>
      
      {/* Header with Title & Mode Switch */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#28282B]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37] shadow-sm">
            <BarChart3 className="w-5 h-5 text-[#D4AF37]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-bold text-white font-['Outfit',sans-serif]">
                Last 7 Days Payout Volume
              </h3>
              <span className="text-[10px] font-mono font-bold text-[#D4AF37] bg-[#D4AF37]/10 border border-[#D4AF37]/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-pulse" />
                Live Disbursals
              </span>
            </div>
            <p className="text-xs text-[#A1A1AA] mt-0.5">
              Roblox group vault transfers fulfilled across BD STUDIO (#36092915)
            </p>
          </div>
        </div>

        {/* View Mode Controls */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div className="flex items-center bg-[#101012] p-1 rounded-xl border border-[#28282B]">
            <button
              onClick={() => setViewMode('volume')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                viewMode === 'volume'
                  ? 'bg-[#D4AF37] text-[#0A0A0C] shadow-sm'
                  : 'text-[#A1A1AA] hover:text-white'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Volume (R$)</span>
            </button>
            <button
              onClick={() => setViewMode('count')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                viewMode === 'count'
                  ? 'bg-[#D4AF37] text-[#0A0A0C] shadow-sm'
                  : 'text-[#A1A1AA] hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Payouts (Tx)</span>
            </button>
            <button
              onClick={() => setViewMode('combined')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
                viewMode === 'combined'
                  ? 'bg-[#D4AF37] text-[#0A0A0C] shadow-sm'
                  : 'text-[#A1A1AA] hover:text-white'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Combined</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Summary Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-5">
        <div className="bg-[#101012] border border-[#28282B] rounded-xl p-3.5 space-y-1">
          <div className="text-[11px] text-[#71717A] uppercase font-semibold flex items-center gap-1">
            <Zap className="w-3 h-3 text-[#D4AF37]" />
            <span>7-Day Total Volume</span>
          </div>
          <div className="text-lg sm:text-xl font-black text-[#D4AF37] font-mono">
            {formatNumber(metrics.totalVolume)} <span className="text-xs text-[#71717A] font-sans font-bold">R$</span>
          </div>
          <div className="text-[10px] text-[#71717A]">
            ~${metrics.totalUsd.toLocaleString('en-US', { minimumFractionDigits: 2 })} USD paid out
          </div>
        </div>

        <div className="bg-[#101012] border border-[#28282B] rounded-xl p-3.5 space-y-1">
          <div className="text-[11px] text-[#71717A] uppercase font-semibold flex items-center gap-1">
            <Layers className="w-3 h-3 text-white" />
            <span>Total Disbursals</span>
          </div>
          <div className="text-lg sm:text-xl font-black text-white font-mono">
            {metrics.totalTransactions} <span className="text-xs text-[#71717A] font-sans font-bold">Payouts</span>
          </div>
          <div className="text-[10px] text-[#71717A]">
            100% automated fulfillments
          </div>
        </div>

        <div className="bg-[#101012] border border-[#28282B] rounded-xl p-3.5 space-y-1">
          <div className="text-[11px] text-[#71717A] uppercase font-semibold flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-[#D4AF37]" />
            <span>Daily Velocity</span>
          </div>
          <div className="text-lg sm:text-xl font-black text-[#D4AF37] font-mono">
            {formatNumber(metrics.avgDailyVolume)} <span className="text-xs text-[#71717A] font-sans font-bold">R$/day</span>
          </div>
          <div className="text-[10px] text-[#71717A]">
            ~{Math.round(metrics.totalTransactions / 7)} transfers/day
          </div>
        </div>

        <div className="bg-[#101012] border border-[#28282B] rounded-xl p-3.5 space-y-1">
          <div className="text-[11px] text-[#71717A] uppercase font-semibold flex items-center gap-1">
            <Award className="w-3 h-3 text-amber-400" />
            <span>Peak Day</span>
          </div>
          <div className="text-lg sm:text-xl font-black text-white font-mono">
            {formatNumber(metrics.peakDay.volume)} <span className="text-xs text-[#71717A] font-sans font-bold">R$</span>
          </div>
          <div className="text-[10px] text-[#71717A]">
            {metrics.peakDay.day} ({metrics.peakDay.payoutCount} payouts)
          </div>
        </div>
      </div>

      {/* Main Recharts Visualizer */}
      <div className="bg-[#101012] border border-[#28282B] rounded-xl p-4 pt-5">
        <div className="flex items-center justify-between text-xs text-[#A1A1AA] mb-2 px-1">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-sm bg-[#D4AF37] inline-block" />
              <span className="font-semibold text-white">Robux Disbursed (R$)</span>
            </div>
            {(viewMode === 'count' || viewMode === 'combined') && (
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-[#A1A1AA] inline-block rounded" />
                <span className="font-semibold text-[#A1A1AA]">Payout Count (Tx)</span>
              </div>
            )}
          </div>
          <span className="text-[11px] text-[#71717A] font-mono hidden sm:inline">
            Hover over bars to inspect details
          </span>
        </div>

        <div className="h-64 sm:h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={sevenDayData}
              margin={{ top: 15, right: 10, left: -15, bottom: 0 }}
              onMouseMove={(state: any) => {
                if (state?.isTooltipActive && state?.activePayload && state.activePayload.length) {
                  setHoveredDay(state.activePayload[0].payload as DailyPayoutVolumePoint);
                }
              }}
              onMouseLeave={() => setHoveredDay(null)}
            >
              <defs>
                <linearGradient id="payoutBarGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#D4AF37" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#8A6D1C" stopOpacity={0.65} />
                </linearGradient>
                <linearGradient id="payoutBarPeakGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#F5D061" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#D4AF37" stopOpacity={0.7} />
                </linearGradient>
                <linearGradient id="payoutBarTodayGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#FFFFFF" stopOpacity={0.95} />
                  <stop offset="100%" stopColor="#D4AF37" stopOpacity={0.7} />
                </linearGradient>
              </defs>

              <CartesianGrid strokeDasharray="3 3" stroke="#28282B" vertical={false} />

              <XAxis
                dataKey="shortDate"
                stroke="#71717A"
                fontSize={11}
                tickLine={false}
                axisLine={{ stroke: '#28282B' }}
              />

              {/* Left Y Axis for Robux Volume */}
              <YAxis
                yAxisId="left"
                stroke="#71717A"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => `${Math.round(val / 1000)}k`}
              />

              {/* Right Y Axis for Transaction Count (when in combined view) */}
              {(viewMode === 'count' || viewMode === 'combined') && (
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  stroke="#A1A1AA"
                  fontSize={10}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(val) => `${val} tx`}
                />
              )}

              <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255, 255, 255, 0.04)' }} />

              {/* Bar for Volume */}
              {(viewMode === 'volume' || viewMode === 'combined') && (
                <Bar
                  yAxisId="left"
                  dataKey="volume"
                  radius={[8, 8, 2, 2]}
                  maxBarSize={48}
                >
                  {sevenDayData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={
                        entry.isPeak
                          ? 'url(#payoutBarPeakGradient)'
                          : entry.isToday
                          ? 'url(#payoutBarTodayGradient)'
                          : 'url(#payoutBarGradient)'
                      }
                      stroke={entry.isToday ? '#FFFFFF' : entry.isPeak ? '#F5D061' : '#D4AF37'}
                      strokeWidth={entry.isToday || entry.isPeak ? 1.5 : 0}
                    />
                  ))}
                </Bar>
              )}

              {/* Line for Transactions Count */}
              {(viewMode === 'count' || viewMode === 'combined') && (
                <Line
                  yAxisId={viewMode === 'count' ? 'left' : 'right'}
                  type="monotone"
                  dataKey="payoutCount"
                  stroke="#FFFFFF"
                  strokeWidth={3}
                  dot={{ r: 4, fill: '#D4AF37', stroke: '#0A0A0C', strokeWidth: 2 }}
                  activeDot={{ r: 7, fill: '#FFFFFF', stroke: '#D4AF37', strokeWidth: 2 }}
                />
              )}
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* 7-Day Quick Day Tabs with Interactive Preview */}
        <div className="grid grid-cols-7 gap-1.5 sm:gap-2 mt-4 pt-4 border-t border-[#28282B]">
          {sevenDayData.map((item, idx) => {
            const isSelected = activePoint.shortDate === item.shortDate;
            return (
              <button
                key={idx}
                onClick={() => setHoveredDay(item)}
                onMouseEnter={() => setHoveredDay(item)}
                className={`p-2 rounded-xl text-center transition cursor-pointer border ${
                  isSelected
                    ? 'bg-[#161618] border-[#D4AF37]/60 shadow-md shadow-[#D4AF37]/10'
                    : 'bg-[#101012] border-[#28282B] hover:bg-[#161618] hover:border-[#71717A]'
                }`}
              >
                <div className="text-[10px] font-bold text-[#71717A] flex items-center justify-center gap-1">
                  <span>{item.day}</span>
                  {item.isToday && <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37]" />}
                </div>
                <div className="text-xs sm:text-sm font-black font-mono text-[#D4AF37] mt-0.5 truncate">
                  {Math.round(item.volume / 1000)}k
                </div>
                <div className="text-[9px] text-[#71717A] font-mono hidden sm:block">
                  {item.payoutCount} tx
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Footer Info & Disbursal Guarantee */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-4 mt-4 border-t border-[#28282B] text-xs text-[#A1A1AA]">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#D4AF37] shrink-0" />
          <span>
            Active Selected: <strong className="text-white">{activePoint.fullDate}</strong> — <span className="text-[#D4AF37] font-bold font-mono">+{formatNumber(activePoint.volume)} R$</span> ({activePoint.payoutCount} payouts)
          </span>
        </div>

        <div className="flex items-center gap-1.5 text-[11px] text-[#D4AF37] font-semibold bg-[#D4AF37]/10 border border-[#D4AF37]/20 px-3 py-1 rounded-full self-start sm:self-auto">
          <Sparkles className="w-3 h-3 text-[#D4AF37]" />
          <span>Average Fulfillment: &lt;15 Seconds</span>
        </div>
      </div>

    </div>
  );
}
