import { useState, type FormEvent } from 'react';
import { generateRobloxAvatarUrl, fetchRobloxPlayer, RobloxUserData } from '../utils/helpers';
import { ROBOLX_GROUPS } from '../data/constants';
import { ShieldCheck, CheckCircle2, Clock, AlertTriangle, ExternalLink, Search, Sparkles, Users, Info, BadgeCheck, Zap, Crown } from 'lucide-react';

interface GroupCheckerSectionProps {
  onEligibleProceed: (username: string) => void;
}

export default function GroupCheckerSection({ onEligibleProceed }: GroupCheckerSectionProps) {
  const [queryUser, setQueryUser] = useState('');
  const [checkedUser, setCheckedUser] = useState<string | null>(null);
  const [playerProfile, setPlayerProfile] = useState<RobloxUserData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<{
    found: boolean;
    isMember: boolean;
    isOwner: boolean;
    roleName: string;
    roleRank: number;
    days: number;
    eligible: boolean;
    groupJoined: string;
    joinDate: string;
  } | null>(null);

  const primaryGroup = ROBOLX_GROUPS[0];

  const handleCheck = async (e: FormEvent) => {
    e.preventDefault();
    if (!queryUser.trim()) return;

    setIsLoading(true);
    setCheckedUser(queryUser.trim());

    const profile = await fetchRobloxPlayer(queryUser.trim());
    setPlayerProfile(profile);
    setIsLoading(false);

    if (profile.found && profile.groupMembership) {
      setResult({
        found: true,
        isMember: profile.groupMembership.isMember,
        isOwner: profile.groupMembership.isOwner,
        roleName: profile.groupMembership.role?.name || (profile.groupMembership.isMember ? 'Member' : 'Not in Group'),
        roleRank: profile.groupMembership.role?.rank ?? (profile.groupMembership.isOwner ? 255 : (profile.groupMembership.isMember ? 1 : 0)),
        days: profile.groupMembership.membershipDays,
        eligible: profile.groupMembership.eligible,
        groupJoined: 'BD STUDIO (#36092915)',
        joinDate: profile.groupMembership.joinDate || 'Not in Group',
      });
    } else if (profile.found) {
      setResult({
        found: true,
        isMember: false,
        isOwner: false,
        roleName: 'Not in Group',
        roleRank: 0,
        days: 0,
        eligible: false,
        groupJoined: 'BD STUDIO (#36092915)',
        joinDate: 'Not Joined',
      });
    } else {
      setResult({
        found: false,
        isMember: false,
        isOwner: false,
        roleName: 'Not in Group',
        roleRank: 0,
        days: 0,
        eligible: false,
        groupJoined: primaryGroup.name,
        joinDate: '',
      });
    }
  };

  return (
    <section id="checker-section" className="py-12 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 text-[#D4AF37] font-bold text-xs uppercase tracking-wider bg-[#D4AF37]/10 border border-[#D4AF37]/20 px-3.5 py-1.5 rounded-full mb-3 shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Roblox Group Eligibility Tool</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black font-['Outfit',sans-serif] text-white">
            14-Day Group Membership Checker
          </h2>
          <p className="text-sm text-[#A1A1AA] mt-2">
            Verify if your Roblox account is in <strong>BD STUDIO (#36092915)</strong> and whether you have satisfied the mandatory 14-day hold for automated payouts.
          </p>
        </div>

        <div className="max-w-3xl mx-auto bg-[#161618] border border-[#28282B] rounded-[14px] p-6 sm:p-8 shadow-2xl space-y-6">
          {/* Lookup Input Form */}
          <form onSubmit={handleCheck} className="space-y-3">
            <label htmlFor="checker-username-input" className="text-sm font-bold text-white">
              Enter your Roblox Username to verify:
            </label>
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <input
                  id="checker-username-input"
                  type="text"
                  value={queryUser}
                  onChange={(e) => setQueryUser(e.target.value)}
                  placeholder="e.g. GamerPro_99, Roblox, Builderman"
                  className="w-full bg-[#101012] border border-[#28282B] focus:border-[#D4AF37] rounded-xl px-4 py-3.5 text-sm text-white placeholder-[#71717A] focus:outline-hidden font-medium"
                />
              </div>
              <button
                type="submit"
                disabled={isLoading || !queryUser.trim()}
                className="px-5 py-3.5 bg-[#D4AF37] hover:bg-[#c49f2e] text-[#0A0A0C] font-bold text-sm rounded-xl transition flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer shadow-md whitespace-nowrap"
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-[#0A0A0C] border-t-transparent rounded-full animate-spin"></div>
                    <span>Checking...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    <span>Check Status</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Results display */}
          {result && checkedUser && (
            <div className="bg-[#101012] border border-[#28282B] rounded-[14px] p-5 space-y-4 animate-in fade-in duration-300">
              <div className="flex items-center justify-between flex-wrap gap-3 border-b border-[#28282B] pb-3">
                <div className="flex items-center gap-3">
                  <img
                    src={playerProfile?.avatarUrl || generateRobloxAvatarUrl(checkedUser)}
                    alt={checkedUser}
                    className="w-12 h-12 rounded-xl border-2 border-[#D4AF37]/50 bg-[#161618] object-cover shadow-md"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = generateRobloxAvatarUrl(checkedUser);
                    }}
                  />
                  <div>
                    <div className="font-bold text-white text-base flex items-center gap-1.5">
                      <span>{playerProfile?.displayName || checkedUser}</span>
                      {playerProfile?.hasVerifiedBadge && (
                        <BadgeCheck className="w-4 h-4 text-[#D4AF37] fill-[#D4AF37]/20" />
                      )}
                    </div>
                    <div className="text-xs text-[#A1A1AA] flex items-center gap-2">
                      <span className="font-mono text-[#D4AF37]">
                        {playerProfile?.id ? `Roblox ID: #${playerProfile.id}` : `@${checkedUser}`}
                      </span>
                      <span>•</span>
                      <span className="text-[#71717A]">Live Roblox Account</span>
                    </div>
                  </div>
                </div>

                {result.isOwner ? (
                  <span className="bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-[#D4AF37] font-bold px-3.5 py-1.5 rounded-full text-xs flex items-center gap-1.5">
                    <Crown className="w-4 h-4 text-[#D4AF37]" />
                    Role: {result.roleName || 'Owner'} (0-Day Hold Bypass)
                  </span>
                ) : result.eligible ? (
                  <span className="bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-[#D4AF37] font-bold px-3.5 py-1.5 rounded-full text-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    Role: {result.roleName} (14-Day Hold Cleared)
                  </span>
                ) : result.isMember ? (
                  <span className="bg-[#28282B] border border-[#3E3E42] text-[#A1A1AA] font-bold px-3.5 py-1.5 rounded-full text-xs flex items-center gap-1.5">
                    <Clock className="w-4 h-4" />
                    Role: {result.roleName} ({14 - result.days}d Left)
                  </span>
                ) : (
                  <span className="bg-[#28282B] border border-[#3E3E42] text-[#71717A] font-bold px-3.5 py-1.5 rounded-full text-xs flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4" />
                    Not in BD STUDIO
                  </span>
                )}
              </div>

              {/* Status details */}
              {result.isOwner ? (
                <div className="space-y-3">
                  <div className="bg-[#161618] border border-[#D4AF37]/40 rounded-xl p-4 text-xs text-[#A1A1AA] leading-relaxed flex items-start gap-3">
                    <Crown className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                    <div>
                      👑 <strong>Verified Group Owner!</strong> As the owner of <strong>{result.groupJoined} (#36092915)</strong>, Roblox 14-day anti-fraud hold restrictions are automatically <strong>bypassed (0-Day Hold)</strong>. You have full instantaneous group payout permissions.
                    </div>
                  </div>

                  <button
                    onClick={() => onEligibleProceed(checkedUser)}
                    className="w-full py-3 bg-[#D4AF37] hover:bg-[#c49f2e] text-[#0A0A0C] font-bold text-sm rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#D4AF37]/20 whitespace-nowrap"
                  >
                    <Crown className="w-4 h-4 fill-[#0A0A0C]" />
                    <span>Proceed to Cashout</span>
                  </button>
                </div>
              ) : result.eligible ? (
                <div className="space-y-3">
                  <div className="bg-[#161618] border border-[#D4AF37]/30 rounded-xl p-4 text-xs text-[#A1A1AA] leading-relaxed">
                    🎉 <strong className="text-white">Verified!</strong> Your account is in <strong>{result.groupJoined} (#36092915)</strong> with official role <strong className="text-[#D4AF37]">{result.roleName}</strong> (joined {result.joinDate}, {result.days} days ago). You have fulfilled the 14-day hold requirement and can cash out Robux instantly!
                  </div>

                  <button
                    onClick={() => onEligibleProceed(checkedUser)}
                    className="w-full py-3 bg-[#D4AF37] hover:bg-[#c49f2e] text-[#0A0A0C] font-bold text-sm rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#D4AF37]/20 whitespace-nowrap"
                  >
                    <Zap className="w-4 h-4 fill-[#0A0A0C]" />
                    <span>Proceed to Cashout</span>
                  </button>
                </div>
              ) : result.isMember ? (
                <div className="space-y-3">
                  <div className="bg-[#161618] border border-[#28282B] rounded-xl p-4 text-xs text-[#A1A1AA] leading-relaxed">
                    ⏳ <strong className="text-white">Membership in progress:</strong> Your account is in BD STUDIO with official role <strong className="text-[#D4AF37]">{result.roleName}</strong> for <strong>{result.days} days</strong> (joined {result.joinDate}). Roblox policy requires <strong>14 continuous days</strong>. You have <strong>{14 - result.days} days</strong> remaining.
                  </div>

                  <button
                    onClick={() => onEligibleProceed(checkedUser)}
                    className="w-full py-2.5 bg-[#28282B] hover:bg-[#323236] text-white font-semibold text-xs rounded-xl transition flex items-center justify-center gap-2 cursor-pointer border border-[#3E3E42] whitespace-nowrap"
                  >
                    <span>Queue Request</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="bg-[#161618] border border-[#28282B] rounded-xl p-4 text-xs text-[#A1A1AA] leading-relaxed">
                    ⚠️ <strong className="text-white">Not joined yet:</strong> This Roblox username is not currently in BD STUDIO. Click below to join the group and begin your 14-day timer immediately.
                  </div>

                  <a
                    href={primaryGroup.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-3 bg-[#D4AF37] hover:bg-[#c49f2e] text-[#0A0A0C] font-bold text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-lg whitespace-nowrap"
                  >
                    <span>Join BD STUDIO Group</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              )}
            </div>
          )}

          {/* Educational Note */}
          <div className="bg-[#101012] border border-[#28282B] rounded-[14px] p-4 flex items-start gap-3 text-xs text-[#71717A]">
            <Info className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
            <div className="space-y-1">
              <strong className="text-[#FFFFFF]">Why does Roblox require 14 days in a group?</strong>
              <p className="leading-relaxed">
                Roblox enforces a platform-wide anti-fraud policy requiring accounts to belong to a group for 14 continuous days before receiving group funds. Joining BD STUDIO once keeps your account permanently eligible forever!
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
