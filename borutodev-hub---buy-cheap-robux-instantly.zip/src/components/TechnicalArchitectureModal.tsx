import { useState } from 'react';
import { 
  Database, 
  Cpu, 
  RefreshCw, 
  ShieldCheck, 
  ArrowRight, 
  Code2, 
  Lock, 
  X, 
  CheckCircle2, 
  Server, 
  Globe, 
  Layers, 
  Clock, 
  FileCode, 
  Sparkles,
  ExternalLink,
  Bot
} from 'lucide-react';

interface TechnicalArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
  sampleUserId?: number;
  sampleUsername?: string;
  sampleEarnings?: number;
  samplePayouts?: number;
}

export default function TechnicalArchitectureModal({
  isOpen,
  onClose,
  sampleUserId = 156711358,
  sampleUsername = 'Player',
  sampleEarnings = 18000,
  samplePayouts = 3500,
}: TechnicalArchitectureModalProps) {
  const [activeTab, setActiveTab] = useState<'dataflow' | 'datastore' | 'bio_polling' | 'payout_engine' | 'security'>('dataflow');

  if (!isOpen) return null;

  const claimableRobux = Math.max(0, sampleEarnings - samplePayouts);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="bg-[#161618] border border-[#28282B] rounded-[14px] w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-[#28282B] bg-[#101012]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#D4AF37]">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white font-['Outfit',sans-serif] flex items-center gap-2">
                <span>Technical Architecture & Data Flow</span>
                <span className="text-[10px] font-mono bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30 px-2 py-0.5 rounded-full">
                  v2.4 Spec
                </span>
              </h2>
              <p className="text-xs text-[#A1A1AA]">
                BorutoDEV Hub Automated Robux Reconciliation & Group Disbursement Pipeline
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#A1A1AA] hover:text-white hover:bg-[#28282B] border border-transparent hover:border-[#28282B] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 p-2 bg-[#101012] border-b border-[#28282B] overflow-x-auto text-xs font-bold">
          <button
            onClick={() => setActiveTab('dataflow')}
            className={`px-3.5 py-2 rounded-xl transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'dataflow' 
                ? 'bg-[#D4AF37] text-[#0A0A0C] font-bold shadow-xs' 
                : 'text-[#A1A1AA] hover:text-white hover:bg-[#28282B]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Complete Architecture Flow</span>
          </button>

          <button
            onClick={() => setActiveTab('datastore')}
            className={`px-3.5 py-2 rounded-xl transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'datastore' 
                ? 'bg-[#D4AF37] text-[#0A0A0C] font-bold shadow-xs' 
                : 'text-[#A1A1AA] hover:text-white hover:bg-[#28282B]'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>Legacy Datastore Ingestion</span>
          </button>

          <button
            onClick={() => setActiveTab('bio_polling')}
            className={`px-3.5 py-2 rounded-xl transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'bio_polling' 
                ? 'bg-[#D4AF37] text-[#0A0A0C] font-bold shadow-xs' 
                : 'text-[#A1A1AA] hover:text-white hover:bg-[#28282B]'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Async Bio Polling Engine</span>
          </button>

          <button
            onClick={() => setActiveTab('payout_engine')}
            className={`px-3.5 py-2 rounded-xl transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'payout_engine' 
                ? 'bg-[#D4AF37] text-[#0A0A0C] font-bold shadow-xs' 
                : 'text-[#A1A1AA] hover:text-white hover:bg-[#28282B]'
            }`}
          >
            <Bot className="w-3.5 h-3.5" />
            <span>Group Payout Dispatch</span>
          </button>

          <button
            onClick={() => setActiveTab('security')}
            className={`px-3.5 py-2 rounded-xl transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'security' 
                ? 'bg-[#D4AF37] text-[#0A0A0C] font-bold shadow-xs' 
                : 'text-[#A1A1AA] hover:text-white hover:bg-[#28282B]'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Security & Anti-Sybil</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-[#A1A1AA] text-sm">
          
          {/* TAB 1: DATAFLOW OVERVIEW */}
          {activeTab === 'dataflow' && (
            <div className="space-y-6 animate-in fade-in duration-150">
              <div className="bg-[#101012] border border-[#28282B] rounded-xl p-5 space-y-4">
                <div className="text-xs font-bold uppercase tracking-wider text-[#D4AF37] flex items-center gap-2">
                  <Server className="w-4 h-4" />
                  <span>End-to-End Pipeline Overview</span>
                </div>
                
                {/* 4 Pipeline Stages Box */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  <div className="bg-[#161618] border border-[#28282B] p-4 rounded-xl space-y-2">
                    <div className="w-7 h-7 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37] font-mono font-bold flex items-center justify-center text-xs">
                      01
                    </div>
                    <div className="font-bold text-white text-xs">Identity Matching</div>
                    <div className="text-[11px] text-[#71717A] leading-tight">
                      Maps username to permanent 64-bit numerical UserId via Users API.
                    </div>
                  </div>

                  <div className="bg-[#161618] border border-[#28282B] p-4 rounded-xl space-y-2">
                    <div className="w-7 h-7 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37] font-mono font-bold flex items-center justify-center text-xs">
                      02
                    </div>
                    <div className="font-bold text-white text-xs">Async Bio Polling</div>
                    <div className="text-[11px] text-[#71717A] leading-tight">
                      Single-use 5-word verification string verified asynchronously via Users endpoint.
                    </div>
                  </div>

                  <div className="bg-[#161618] border border-[#28282B] p-4 rounded-xl space-y-2">
                    <div className="w-7 h-7 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37] font-mono font-bold flex items-center justify-center text-xs">
                      03
                    </div>
                    <div className="font-bold text-white text-xs">Datastore Ingestion</div>
                    <div className="text-[11px] text-[#71717A] leading-tight">
                      Calculates Σ Earnings minus Σ Payouts from Simply PLS DONATE historical tables.
                    </div>
                  </div>

                  <div className="bg-[#161618] border border-[#28282B] p-4 rounded-xl space-y-2">
                    <div className="w-7 h-7 rounded-lg bg-[#D4AF37]/20 text-[#D4AF37] font-mono font-bold flex items-center justify-center text-xs">
                      04
                    </div>
                    <div className="font-bold text-white text-xs">Group Payout Dispatch</div>
                    <div className="text-[11px] text-[#71717A] leading-tight">
                      Automated bot instances dispatch HTTP POST to Groups/Economy Payouts API.
                    </div>
                  </div>
                </div>
              </div>

              {/* Endpoints & Standards */}
              <div className="bg-[#101012] border border-[#28282B] rounded-xl p-5 space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-[#71717A]">
                  Official External Roblox Endpoints Integrated
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                  <div className="bg-[#161618] p-2.5 rounded-xl border border-[#28282B] text-white">
                    <span className="text-[#D4AF37] font-bold">POST</span> users.roblox.com/v1/usernames/users
                  </div>
                  <div className="bg-[#161618] p-2.5 rounded-xl border border-[#28282B] text-white">
                    <span className="text-[#D4AF37] font-bold">GET</span> thumbnails.roblox.com/v1/users/avatar-headshot
                  </div>
                  <div className="bg-[#161618] p-2.5 rounded-xl border border-[#28282B] text-white">
                    <span className="text-[#D4AF37] font-bold">GET</span> users.roblox.com/v1/users/{'{UserId}'}
                  </div>
                  <div className="bg-[#161618] p-2.5 rounded-xl border border-[#28282B] text-white">
                    <span className="text-[#D4AF37] font-bold">POST</span> groups.roblox.com/v1/groups/{'{GroupId}'}/payouts
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DATASTORE INGESTION & MATHEMATICAL FORMULA */}
          {activeTab === 'datastore' && (
            <div className="space-y-6 animate-in fade-in duration-150">
              <div className="bg-[#101012] border border-[#28282B] rounded-xl p-6 space-y-4">
                <div className="text-xs font-bold uppercase tracking-wider text-[#D4AF37] flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  <span>Legacy Datastore Ingestion Logic</span>
                </div>
                <p className="text-xs text-[#A1A1AA] leading-relaxed">
                  Historical donation logs from earlier Simply PLS DONATE games are stored in an external relational database. When a user enters their account, the backend queries stored transaction tables by unique <code className="text-[#D4AF37] font-mono">UserId</code> to calculate total owed Robux using:
                </p>

                {/* Mathematical Formula Card */}
                <div className="bg-[#161618] border border-[#D4AF37]/40 rounded-xl p-5 text-center shadow-inner space-y-2">
                  <div className="text-xs uppercase font-bold text-[#71717A]">Reconciliation Formula</div>
                  <div className="font-mono text-base sm:text-xl font-black text-[#D4AF37] tracking-wider">
                    Claimable Robux = &sum; Legacy Earnings &minus; &sum; Historical Payouts
                  </div>
                  <div className="text-[11px] text-[#71717A] font-mono pt-1">
                    $\text&#123;Claimable Robux&#125; = \sum \text&#123;Legacy Earnings&#125; - \sum \text&#123;Historical Payouts&#125;$
                  </div>
                </div>

                {/* Interactive Live Calculation Sample */}
                <div className="bg-[#161618] border border-[#28282B] rounded-xl p-4 space-y-3">
                  <div className="text-xs font-bold text-white flex items-center justify-between">
                    <span>Sample Account Ledger Calculation (@{sampleUsername} &bull; #{sampleUserId}):</span>
                    <span className="text-[#D4AF37] font-mono font-bold">{claimableRobux.toLocaleString()} R$ Net Owed</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="bg-[#101012] p-2.5 rounded-lg border border-[#28282B]">
                      <div className="text-[10px] text-[#71717A] uppercase">Legacy Earnings</div>
                      <div className="font-mono font-bold text-[#D4AF37] mt-0.5">+{sampleEarnings.toLocaleString()} R$</div>
                    </div>
                    <div className="bg-[#101012] p-2.5 rounded-lg border border-[#28282B]">
                      <div className="text-[10px] text-[#71717A] uppercase">Historical Payouts</div>
                      <div className="font-mono font-bold text-white mt-0.5">&minus;{samplePayouts.toLocaleString()} R$</div>
                    </div>
                    <div className="bg-[#101012] p-2.5 rounded-lg border border-[#D4AF37]/40">
                      <div className="text-[10px] text-[#D4AF37] uppercase font-bold">Claimable Balance</div>
                      <div className="font-mono font-black text-[#D4AF37] mt-0.5">{claimableRobux.toLocaleString()} R$</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: ASYNC BIO POLLING ENGINE */}
          {activeTab === 'bio_polling' && (
            <div className="space-y-6 animate-in fade-in duration-150">
              <div className="bg-[#101012] border border-[#28282B] rounded-xl p-6 space-y-4">
                <div className="text-xs font-bold uppercase tracking-wider text-[#D4AF37] flex items-center gap-2">
                  <RefreshCw className="w-4 h-4" />
                  <span>Asynchronous Bio Polling Engine</span>
                </div>
                <p className="text-xs text-[#A1A1AA] leading-relaxed">
                  To verify account control without requiring sensitive credentials (passwords, 2FA, session tokens), the web server generates a unique, single-use 5-word verification string. A background worker periodically polls the public user profile endpoint (<code className="text-[#D4AF37] font-mono">https://users.roblox.com/v1/users/{'{UserId}'}</code>) and executes case-insensitive string-matching logic to confirm profile updates.
                </p>

                <div className="bg-[#161618] border border-[#28282B] rounded-xl p-4 space-y-3 font-mono text-xs">
                  <div className="text-[#71717A] text-[11px] uppercase font-bold">Matching Algorithm Flow</div>
                  <div className="text-[#A1A1AA] space-y-1.5 pl-2 border-l-2 border-[#D4AF37]/50">
                    <div>1. Generated Phrase: <span className="text-[#D4AF37] font-bold">&quot;pixel shadow nebula vortex falcon&quot;</span></div>
                    <div>2. Query: <span className="text-white">GET https://users.roblox.com/v1/users/{sampleUserId}</span></div>
                    <div>3. Extracted Field: <span className="text-white">response.description</span></div>
                    <div>4. Normalization: <span className="text-[#71717A]">clean(bio).includes(clean(expectedPhrase))</span></div>
                    <div>5. Status: <span className="text-[#D4AF37] font-bold">200 OK &bull; Ownership Verified</span></div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: GROUP PAYOUT API DISPATCH */}
          {activeTab === 'payout_engine' && (
            <div className="space-y-6 animate-in fade-in duration-150">
              <div className="bg-[#101012] border border-[#28282B] rounded-xl p-6 space-y-4">
                <div className="text-xs font-bold uppercase tracking-wider text-[#D4AF37] flex items-center gap-2">
                  <Bot className="w-4 h-4" />
                  <span>Group Payout API Dispatch</span>
                </div>
                <p className="text-xs text-[#A1A1AA] leading-relaxed">
                  Upon successful bio validation, the web server queues a payout request. Automated bot instances containing authorized group management cookies or Open Cloud API keys issue HTTP POST requests to <code className="text-[#D4AF37] font-mono">https://groups.roblox.com/v1/groups/{'{GroupId}'}/payouts</code> (and Economy payouts endpoint) to distribute Robux from the group treasury directly into player accounts without manual human handling.
                </p>

                <div className="bg-[#161618] border border-[#28282B] rounded-xl p-4 space-y-2 text-xs">
                  <div className="text-[#71717A] text-[11px] font-bold uppercase">Payload Structure</div>
                  <pre className="bg-[#101012] p-3 rounded-lg border border-[#28282B] text-[#D4AF37] font-mono text-[11px] overflow-x-auto">
{`{
  "PayoutType": "FixedAmount",
  "Recipients": [
    {
      "recipientId": ${sampleUserId},
      "recipientType": "User",
      "amount": ${claimableRobux || 5000}
    }
  ]
}`}
                  </pre>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: SYSTEM CONSTRAINTS & SECURITY CONTROLS */}
          {activeTab === 'security' && (
            <div className="space-y-6 animate-in fade-in duration-150">
              <div className="bg-[#101012] border border-[#28282B] rounded-xl p-6 space-y-4">
                <div className="text-xs font-bold uppercase tracking-wider text-[#D4AF37] flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" />
                  <span>System Constraints & Security Controls</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Constraint 1 */}
                  <div className="bg-[#161618] border border-[#28282B] rounded-xl p-4 space-y-2">
                    <div className="flex items-center gap-2 font-bold text-white text-xs">
                      <Clock className="w-4 h-4 text-[#D4AF37]" />
                      <span>Roblox 14-Day Group Membership Rule</span>
                    </div>
                    <p className="text-xs text-[#A1A1AA] leading-relaxed">
                      Roblox platform security policies enforce a mandatory 14-day waiting period for new group members before group funds can be distributed to their account. The checker validates join timestamps via public group role endpoints.
                    </p>
                  </div>

                  {/* Constraint 2 */}
                  <div className="bg-[#161618] border border-[#28282B] rounded-xl p-4 space-y-2">
                    <div className="flex items-center gap-2 font-bold text-white text-xs">
                      <Lock className="w-4 h-4 text-[#D4AF37]" />
                      <span>Rate-Limiting & Anti-Sybil Safeguards</span>
                    </div>
                    <p className="text-xs text-[#A1A1AA] leading-relaxed">
                      Frontend security checks block automated bot scripts from spamming verification endpoints, while server-side rate limits prevent brute-force bio checking and safeguard Roblox API quotas.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 sm:p-5 border-t border-[#28282B] bg-[#101012] flex items-center justify-between flex-wrap gap-3 text-xs">
          <div className="text-[#71717A] flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
            <span>Complies with Roblox Open Cloud & Public API specifications</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#161618] hover:bg-[#28282B] text-white font-semibold text-xs rounded-xl border border-[#28282B] transition cursor-pointer whitespace-nowrap"
          >
            Close Specs
          </button>
        </div>

      </div>
    </div>
  );
}
