export interface RobloxAccount {
  username: string;
  displayName: string;
  userId: number;
  avatarUrl: string;
  isMemberOfGroup: boolean;
  membershipDays: number;
  eligibleForPayout: boolean;
}

export interface CashoutTicket {
  id: string;
  date: string;
  timestamp: number;
  username: string;
  avatarUrl: string;
  robuxAmount: number;
  payoutUsd?: number;
  method: string;
  destination: string;
  status: 'processing' | 'verifying_game' | 'funds_clearing' | 'completed' | 'sent' | 'failed';
  groupName: string;
  payoutTxId?: string;
  speedMinutes?: number;
  liveDelivered?: boolean;
  deliveryNotice?: string;
}

// Backward compatibility alias
export type Order = CashoutTicket;

export interface TrustpilotReview {
  id: string;
  author: string;
  country: string;
  countryCode: string;
  rating: number;
  title: string;
  body: string;
  date: string;
  verifiedPurchase: boolean;
  robuxCashedOut?: number;
}

export interface GroupInfo {
  id: string;
  name: string;
  robloxGroupId: number;
  memberCount: number;
  stock: number;
  status: 'active' | 'restocking' | 'full';
  link: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: 'cashout' | '14-day-rule' | 'payouts' | 'safety' | 'games';
}
