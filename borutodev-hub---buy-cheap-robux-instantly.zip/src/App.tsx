import { useState, useEffect } from 'react';
import { CashoutTicket } from './types';
import { generateRobloxAvatarUrl } from './utils/helpers';

// Components
import RecentPayoutsTicker from './components/RecentPayoutsTicker';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import CashoutSection from './components/CashoutSection';
import GroupCheckerSection from './components/GroupCheckerSection';
import CashoutRatesSection from './components/CashoutRatesSection';
import StockSection from './components/StockSection';
import HowItWorks from './components/HowItWorks';
import FAQSection from './components/FAQSection';
import DiscordBanner from './components/DiscordBanner';
import Footer from './components/Footer';
import CashoutTrackerModal from './components/CashoutTrackerModal';
import PolicyModal from './components/PolicyModal';

export default function App() {
  const [tickets, setTickets] = useState<CashoutTicket[]>([]);
  const [isTrackerOpen, setIsTrackerOpen] = useState(false);
  const [policyType, setPolicyType] = useState<'terms' | 'privacy' | 'refund' | null>(null);
  const [targetUsernameForCashout, setTargetUsernameForCashout] = useState<string>('');

  // Load saved cashout tickets from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('borutodev_cashout_tickets');
      if (saved) {
        setTickets(JSON.parse(saved));
      } else {
        const initialTicket: CashoutTicket = {
          id: 'CSH-849120',
          date: 'Today',
          timestamp: Date.now() - 3600000,
          username: 'BorutoFan_01',
          avatarUrl: generateRobloxAvatarUrl('BorutoFan_01'),
          robuxAmount: 10000,
          method: 'Automated Group Payout (BD STUDIO)',
          destination: '@BorutoFan_01 (Roblox Account)',
          status: 'completed',
          groupName: 'BD STUDIO (#36092915)',
          payoutTxId: 'tx_csh_8f9a2b1c',
          speedMinutes: 1,
        };
        setTickets([initialTicket]);
      }
    } catch (e) {
      // ignore
    }
  }, []);

  const handleTicketCreated = (newTicket: CashoutTicket) => {
    setTickets((prev) => {
      const updated = [newTicket, ...prev];
      try {
        localStorage.setItem('borutodev_cashout_tickets', JSON.stringify(updated));
      } catch (err) {
        // ignore
      }
      return updated;
    });
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleEligibleProceed = (user: string) => {
    setTargetUsernameForCashout(user);
    scrollToSection('cashout-section');
    setTimeout(() => {
      const input = document.getElementById('roblox-username-input') as HTMLInputElement | null;
      if (input) {
        input.value = user;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.focus();
      }
    }, 100);
  };

  const handleSelectAmountForCashout = (amount: number) => {
    scrollToSection('cashout-section');
    const input = document.getElementById('cashout-amount-input') as HTMLInputElement | null;
    if (input) {
      input.value = String(amount);
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0C] text-[#A1A1AA] flex flex-col font-['Plus_Jakarta_Sans',sans-serif] selection:bg-[#D4AF37]/30 selection:text-white">
      {/* Live Verified Group Payouts Ticker */}
      <RecentPayoutsTicker />

      {/* Main Navbar */}
      <Navbar
        onOpenTracker={() => setIsTrackerOpen(true)}
        onOpenChecker={() => scrollToSection('checker-section')}
        onOpenRates={() => scrollToSection('rates-section')}
        onOpenStock={() => scrollToSection('stock-section')}
        onOpenFaq={() => scrollToSection('faq-section')}
        onOpenCashout={() => scrollToSection('cashout-section')}
        ticketCount={tickets.length}
      />

      {/* Main Cashout Portal View */}
      <main className="flex-1 space-y-2">
        <HeroSection
          onStartCashout={() => scrollToSection('cashout-section')}
          onOpenChecker={() => scrollToSection('checker-section')}
          onOpenVault={() => scrollToSection('stock-section')}
        />

        <CashoutSection
          initialUsername={targetUsernameForCashout}
          onTicketCreated={handleTicketCreated}
          onOpenVault={() => scrollToSection('stock-section')}
          onOpenTracker={() => setIsTrackerOpen(true)}
        />

        <GroupCheckerSection onEligibleProceed={handleEligibleProceed} />

        <CashoutRatesSection
          onSelectAmountForCashout={handleSelectAmountForCashout}
        />

        <StockSection />

        <HowItWorks />

        <FAQSection />

        <DiscordBanner />
      </main>

      {/* Footer */}
      <Footer
        onOpenPolicy={(type) => setPolicyType(type)}
        onOpenRates={() => scrollToSection('rates-section')}
        onOpenChecker={() => scrollToSection('checker-section')}
        onOpenTracker={() => setIsTrackerOpen(true)}
      />

      {/* Cashout Ticket Tracker Modal */}
      <CashoutTrackerModal
        isOpen={isTrackerOpen}
        onClose={() => setIsTrackerOpen(false)}
        tickets={tickets}
      />

      {/* Legal & Policy Modal */}
      <PolicyModal
        type={policyType}
        onClose={() => setPolicyType(null)}
      />
    </div>
  );
}
