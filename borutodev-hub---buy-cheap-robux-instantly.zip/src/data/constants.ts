import { TrustpilotReview, GroupInfo, FAQItem } from '../types';

export const ROBOLX_GROUPS: GroupInfo[] = [
  {
    id: 'bd-studio-main',
    name: 'BD STUDIO',
    robloxGroupId: 36092915,
    memberCount: 20,
    stock: 580000,
    status: 'active',
    link: 'https://www.roblox.com/communities/36092915/BD-STUDIO#!/about',
  },
];

export const TRUSTPILOT_REVIEWS: TrustpilotReview[] = [
  {
    id: 'rev-1',
    author: 'Kacper M.',
    country: 'Poland',
    countryCode: 'PL',
    rating: 5,
    title: 'Instant 25,000 Robux group payout directly to my account',
    body: 'Verified my username, checked my 14-day BD STUDIO hold, and clicked Claim. The Robux showed up in my Roblox balance immediately with zero manual wait!',
    date: '1 day ago',
    verifiedPurchase: true,
    robuxCashedOut: 25000,
  },
  {
    id: 'rev-2',
    author: 'Jayden R.',
    country: 'United States',
    countryCode: 'US',
    rating: 5,
    title: 'Super smooth automated payout',
    body: 'BD STUDIO automated payout engine verified my Roblox profile and transferred 10k Robux directly to my account in seconds.',
    date: '2 days ago',
    verifiedPurchase: true,
    robuxCashedOut: 10000,
  },
  {
    id: 'rev-3',
    author: 'Lucas V.',
    country: 'Germany',
    countryCode: 'DE',
    rating: 5,
    title: 'Best automated system for developers & players',
    body: 'The owner does not even need to be online. The system handles everything automatically via Roblox group payouts.',
    date: '4 days ago',
    verifiedPurchase: true,
    robuxCashedOut: 5000,
  },
];

export const FAQ_ITEMS: FAQItem[] = [
  {
    category: 'cashout',
    question: 'How does the automated group payout work?',
    answer: 'Enter your Roblox username and select how much Robux to claim. The system automatically validates your 14-day membership in BD STUDIO (#36092915) and triggers the official Roblox group payout API to deliver the Robux straight into your player account without any manual admin action.',
  },
  {
    category: '14-day-rule',
    question: 'Why does Roblox require 14 days of group membership?',
    answer: 'Roblox platform policy requires all accounts to be members of a group for at least 14 days before group funds can be disbursed to them. You can join BD STUDIO (#36092915) to start your 14-day timer. Once 14 days pass, you can claim instant payouts at any time.',
  },
  {
    category: 'safety',
    question: 'Do I ever need to enter passwords, emails, or cookies?',
    answer: 'NO, NEVER! You only enter your public Roblox username. We will never ask for your password, email, pin, verification code, or account cookies.',
  },
  {
    category: 'payouts',
    question: 'How is the Robux disbursed?',
    answer: 'The system automatically executes a direct group payout from the BD STUDIO vault into your Roblox account balance with 0 manual steps.',
  },
  {
    category: 'games',
    question: 'How fast is the Robux deposited?',
    answer: 'Payouts are executed instantly via the automated group payout engine. Once processed, the Robux reflects immediately in your Roblox account transactions.',
  },
];
